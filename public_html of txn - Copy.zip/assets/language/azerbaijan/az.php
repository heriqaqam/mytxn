
<?php

// home page
$string['new-auction']                ='Yenİ Hərrac';
$string['new-auction_desc']           ='Avtomobil 5200 km yol qət etmişdir.Sag qapısında əzik vardır. 
                                    Təmir xərci təqribi 500 AZN təşgil edir.';
$string['car_at_auction']             ='Hərracda Olan avtomobİllər';
$string['car_at_auction_desc']        ='Hazırda hərracda olan və bitmə vaxtına az qalan avtomobillər. Hərracda iştirak etmək üçün 
                                    zəhmət olmasa qeydiyyatdan keçin və şəxsiyyət vəsiqənizi yükləyin.';
$string['auction_time']               ='Hərracın Başlamasına qalıb';
$string['auction_time_day']           ='GÜN';
$string['auction_time_hour']          ='SAAT';
$string['auction_time_minute']        ='DƏQ';
$string['auction_time_second']        ='SAN';
$string['auction_opening_value']      ='HƏRRACIN AÇILIŞ QİYMƏTİ:';
$string['car_parametrs']              ='Avtomobİlİn parametrlərİ';
$string['km']                         ='Kilometr sayacı:';
$string['focusing_moments']           ='Diqqət çəkən məqamlar:';
$string['demage']                     ='Əsas Zərər:';
$string['secondary_damage']           ='İkinci dərəcəli zərər:';
$string['retail_cost:']               ='Pərakəndə satış dəyəri:';
$string['car_type']                   ='Növü:';
$string['transport_caetgory']         ='Nəqliyyat kateqoriyası:';
$string['car_color']                  ='Rəngi:';
$string['engine_type']                ='Mühərrikin növü:';
$string['cylinders']                  ='Silindirlər:';
$string['transmission']               ='Transmissiya:';
$string['drive']                      ='wheel Drive';
$string['fuel']                       ='Yanacaq:'
$string['keys']                       ='Açarlar:';
$string['follow']                     ='İZLƏMƏYƏ AL';
$string['auction_to_start']           ='Hərracın Başlamasına qalıb';
$string['users_feedback']             ='İSTİFADƏÇI RƏYLƏRİ';
$string['users_feedback_desc']        ='I could probably go into sales for you. We have seen amazing results already. I am
                                    so pleased with this product. The best on the net!';
$string['card_header-title']          ='ƏN SON YAZILARIMIZ';
$string['card_title']                 ='The Best in dolor sit amet';
$string['card_desc']                  ='The Best in dolor sit amet consectetur adipisicing elit sed simply dummy text of 
                                    the printing and typesetting';
$string['footer_logo_under_word']     ='Nam eu laoreet dui, quis aliquet neque. Phasellus accumsan nibh nibh, sit amet 
                                    vehicula mauris porta quis.'
$string['footer_pages_title']         ='SƏHİFƏLƏR';
$string['footer_sosical_made']        ='Sosyal Şəbəkədə bİz';



?>