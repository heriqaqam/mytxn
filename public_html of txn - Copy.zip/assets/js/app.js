


$(function () {
  $(".menu").click(function () {
    $(".media-alt").slideToggle();
  })
})

$(function () {
  $(".menu2").click(function () {
    $(".media-alt-2").slideToggle();
  })
})

$(function () {
  $(".alt1").click(function () {
    $(".menu-alt1").slideToggle();
  })
})



function increaseValue() {
  var value = parseInt(document.getElementById('number').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number').value = value;
}

function decreaseValue() {
  var value = parseInt(document.getElementById('number').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number').value = value;
}

function supTotal(){
  var total=$('#number').val()*$('#number').attr('data-price');
  $('#total').html(total);
}

function increaseValue2() {
  var value = parseInt(document.getElementById('number2').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number2').value = value;
}

function decreaseValue2() {
  var value = parseInt(document.getElementById('number2').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number2').value = value;
}

function increaseValue3() {
  var value = parseInt(document.getElementById('number3').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number3').value = value;
}

function decreaseValue3() {
  var value = parseInt(document.getElementById('number3').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number3').value = value;
}

function increaseValue4() {
  var value = parseInt(document.getElementById('number4').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number4').value = value;
}

function decreaseValue4() {
  var value = parseInt(document.getElementById('number4').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number4').value = value;
}

function increaseValue5() {
  var value = parseInt(document.getElementById('number5').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number5').value = value;
}

function decreaseValue5() {
  var value = parseInt(document.getElementById('number5').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number5').value = value;
}

function increaseValue6() {
  var value = parseInt(document.getElementById('number6').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number6').value = value;
}

function decreaseValue6() {
  var value = parseInt(document.getElementById('number6').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number6').value = value;
}

function increaseValue7() {
  var value = parseInt(document.getElementById('number7').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number7').value = value;
}

function decreaseValue7() {
  var value = parseInt(document.getElementById('number7').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number7').value = value;
}


function myFunction() {
  var element = document.getElementById("removestyle");
  element.classList.remove("violet");
  element.classList.add("green");
  var element = document.getElementById("remove2");
  element.classList.remove("green");
  element.classList.add("violet");
}

function myFunction2() {
  var element = document.getElementById("remove2");
  element.classList.remove("violet");
  element.classList.add("green");
  var element = document.getElementById("removestyle");
  element.classList.remove("green");
  element.classList.add("violet");
}


function tabclick(webname) {
  var content = document.getElementsByClassName("content");
  for (i = 0; i < content.length; i++) {
    content[i].style.display = "none"
  }
  document.getElementById(webname).style.display = "block";
  return false;
}

$('.tab').click(function(){
  return false; 
})

$(document).ready(function () {
  $(".tab1").click(function () {
    $(".tab1").removeClass("tab2");
    $(".tab1").addClass("active");
    $(".tab2").removeClass("active");
  })
})

$(document).ready(function () {
  $(".tab2").click(function () {
    $(".tab2").addClass("active");
    $(".tab1").removeClass("active");
    $(".tab1").addClass("tab2");

  })
})

$('.open-categories').click(function(){
  $('.mobile-visible').show();
  $('.mobile-dropdown').find('fa-plus-square').addClass('fa-minus-square');
  // $('.mobile-dropdown ul').hide();
});

$('.close-menu').click(function(){
  $('.mobile-visible').hide();
  // $('.mobile-dropdown ul').hide();
})

$('#feature_add_btn').click(function(){
  var item=$('.feature-item').eq(0).clone();
  $('#features').append(item);
})
function hideBodyScroll() {
  $('body').addClass('scroll-hidden');
}

// Function to show the body scroll
function showBodyScroll() {
  $('body').removeClass('scroll-hidden');
}

$(document).click(function(e){
  if(!$(e.target).closest('.mobile-menu').length){
    if(!$(e.target).closest('.menu').length && !$(e.target).closest('.open-categories').length){
      
        $('.mobile-menu').animate({
            marginLeft:'-=5000'
        },500,function(){

            $('.mobile-visible').hide();
        });
    }else{
        $('.mobile-menu').animate({
            marginLeft:'0'
        },500,function(){
          $('.mobile-visible').show();
        });
    }
  } 

});
$('.mobile-visible').on('show', function() {
  hideBodyScroll();
});

// Example event handler for hiding the div
$('.mobile-visible').on('hide', function() {
  showBodyScroll();
});

$(document).ready(function() {
  // Collapse all submenus initially

  $('.mnu_item').click(function(e) {
      e.stopPropagation();

      var $submenu = $(this).siblings('ul');
      $submenu.slideToggle();
      $(this).find('i').toggleClass('fa-plus-square fa-minus-square');

      var $parentMenu = $(this).closest('.mobile-dropdown');
      if ($submenu.is(':visible')) {
          $parentMenu.siblings().find('ul:visible').not($submenu).slideUp();
          $parentMenu.siblings().find('.mnu_item i').removeClass('fa-plus-square').addClass('fa-minus-square');
      }
  });

  $('.mobile-dropdown a').click(function(e) {
      e.stopPropagation();
  });

  
});

$(document).ready(function() {
  // Collapse all submenus initially

  $('.mnu_item1').click(function(e) {
      e.stopPropagation();

      var $submenu = $(this).siblings('ul');
      $submenu.slideToggle();
      $(this).find('i').toggleClass('fa-plus-square fa-minus-square');

      var $parentMenu = $(this).closest('.myul');
      if ($submenu.is(':visible')) {
          $parentMenu.siblings().find('ul:visible').not($submenu).slideUp();
          $parentMenu.siblings().find('.mnu_item1 i').removeClass('fa-plus-square').addClass('fa-minus-square');
      }
  });

  $('.myul a').click(function(e) {
      e.stopPropagation();
  });


});

