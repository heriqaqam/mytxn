var previousValue;

$(function () {
  var previousValue;
  var imageindex = []
  //noftication
  function notification(text, type = "info") {
    /*  var icon = 'info';
        switch (type) {
            case 'warning':
                icon = 'warning';
                break;
            case 'danger':
                icon = 'warning';
                break;
        }
        var html = '<div class="noftication noftication-' + type + '"><span class="fa fa-close"></span><div><i class="fa fa-' + icon + '"></i>' + text + '</div></div>';
        $('body').append(html);
        var obj = $('.noftication');
        obj.animate({
            'right': '20px'
        }, 500);
        setTimeout(function () {
            obj.animate({
                'right': '-50%'
            }, 400, function () {
                obj.remove();
            });
        }, 3000); */
  }

  $(document).on("click", ".noftication>span", function () {
    var obj = $(this).parent();
    obj.animate(
      {
        right: "-50%",
      },
      400,
      function () {
        obj.remove();
      }
    );
  });
  //end noftication

  var my_functions = Object();

  $("#mobile_menu").html($("#desktop_menu").clone());

  $(".slideAll").slick({
    autoplay: true,
    dots: false,
    infinite: false,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    cssEase: "linear",
    prevArrow:
      '<button class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
    nextArrow:
      '<button class="slick-next"><i class="fas fa-chevron-right"></i></button>',
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
        },
      },
    ],
  });
  //small-slider

  $(".small-slider").slick({
    dots: false,
    arrows: false,
    infinite: false,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
    cssEase: "linear",
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: true,
        },
      },
    ],
  });

  $(".product-images-slider").slick({
    dots: false,
    arrows: false,
    slidesToShow: 4,
    slidesToScroll: 1,
    cssEase: "linear",
    infinite: false,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 4,
        },
      },
    ],
  });

  $("#otherproduct").slick({
    dots: false,
    arrows: false,
    speed: 300,
    slidesToShow: 4,
    slidesToScroll: 1,
    infinite: false,
    cssEase: "linear",
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
        },
      },
    ],
  });

  $(".firstpic").slick({
    dots: false,
    arrows: true,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    infinite: false,
    cssEase: "linear",
    prevArrow:
      '<button class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
    nextArrow:
      '<button class="slick-next"><i class="fas fa-chevron-right"></i></button>',
  });

  function getId(url) {
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=|\/shorts\/)([^#\&\?]*).*/;
  const match = url.match(regExp);
  return match && match[2].length === 11 ? match[2] : null;
}

$.each($(".video-fluid"), function (item, val) {
  var src = $(".video-fluid:eq(" + item + ")").attr("data-src");
  var videoId = getId(src);
  if (src.includes("/shorts/")) {
    // If the link is in the shorts format, convert it to the regular format
    src = "https://youtu.be/" + videoId;
  }
  $(".video-fluid:eq(" + item + ")").attr(
    "src",
    "https://www.youtube.com/embed/" + videoId
  );
});

  $(".product-images-slider .product-thumb-item").click(function () {
    var index = $(this).index();
    $(".firstpic").slick("goTo", index);

    $(".product-thumb-item").removeClass("active");
    $(this).addClass("active");
  });

  $(".slider-writen").slick({
    dots: true,
    arrows: false,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    infinite: true,
    cssEase: "linear",
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
        },
      },
    ],
  });

  $(".auction-single").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    asNavFor: ".auction-bottom-imgs",
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
        },
      },
    ],
  });

  $(".auction-bottom-imgs").slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    asNavFor: ".auction-single",
    dots: false,
    centerMode: true,
    focusOnSelect: true,
    infinite: true,
    variableWidth: true,
    waitForAnimate: true,
    prevArrow:
      '<button class="slider-left-arrow"><i class="fas fa-chevron-left"></i></button>',
    nextArrow:
      '<button class="slider-right-arrow"><i class="fas fa-chevron-right"></i></button>',
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
          // infinite: true
        },
      },
    ],
  });

  function scrollAds() {
    if ($(document).scrollTop() > 90) {
      $(".advertising").addClass("advertising-scroll");
    } else {
      $(".advertising").removeClass("advertising-scroll");
    }
  }
  scrollAds();

  $(document).scroll(function () {
    scrollAds();
  });

  $(".modal-create").click(function () {
    $(".modal-title.active").removeClass("active");
    $(".create-form").show();
    $(this).addClass("active");
    $("input[name=type]").val($(this).attr("data-type"));
    $(".sing-in-form").hide();
  });

  $(".modal-sing-in").click(function () {
    $(".modal-title.active").removeClass("active");
    $(".sing-in-form").show();
    $(this).addClass("active");
    $("input[name=type]").val($(this).attr("data-type"));
    $(".create-form").hide();
  });

  $(".respons-menu").click(function () {
    $(".opening-respons-menu").toggleClass("add-respons-menu");
    $(".opening-respons-menu").animate(
      {
        left: "0",
      },
      100,
      function () {
        $(".close-responsive").click(function () {
          $(".opening-respons-menu").animate(
            {
              left: "-100%",
            },
            100
          );
        });
        return false;
      }
    );
  });

  $(document).on("click", ".opening-respons-menu .menu-after", function () {
    return false;
  });

  $(".left-childs").click(function () {
    var selector = $(this).attr("data-id");
    $("div[data-object]").hide();
    $("div[data-object=" + selector + "]").show();
  });

  $(".comments-part").click(function () {
    $(".profile-notification").fadeToggle(100);
  });

  $(".login_btn,.register_btn").click(function () {
    $("#form_modal").modal("show");
    $("body").addClass("body-overflow");
  });

  $("#form_modal").on("hidden.bs.modal", function (e) {
    $("body").removeClass("body-overflow");
  });

  $(".estimate-star").click(function () {
    $(".estimate-star i").removeClass("fa").addClass("far");
    for (i = 0; i <= $(this).index(); i++) {
      $(".estimate-star:eq(" + i + ") i").addClass("fa");
    }
    $(this).find("input").prop("checked", true);
  });

  $(document).on("click", "button[data-form-id]", function () {
    $("#" + $(this).attr("data-form-id")).submit();
    return false;
  });

  $(document).on("change", "#terms_check", function () {
    if ($(this).prop("checked")) {
      $("button[data-form-id]").prop("disabled", false);
    } else {
      $("button[data-form-id]").prop("disabled", true);
    }
  });

  function ajaxForm_load() {
    $("form:not([data-stop])").ajaxForm({
      beforeSend: function () {
        loading();
      },
      uploadProgress: function (h, o, t, faiz) {},
      complete: function (x) {
        console.log(x)
        var response = JSON.parse(x.responseText);
        loading(false);
        loading1(false);
        $.each(response, function (key, value) {
          $("[data-error=" + key + "]").html(value);
        });

        my_functions[response.req_type](response);

        if (response.status == true) {
          $("form input").val("");
          $("form textarea").val("");
        }
      },
    });
  }
  ajaxForm_load();

  my_functions["login"] = login;
  my_functions["register"] = register;
  my_functions["confirmation"] = confirmation;
  my_functions["recovery"] = recovery;
  my_functions["new_password"] = new_password;
  my_functions["addProduct"] = addProduct;
  my_functions["createstore"] = createstore;
  my_functions["register_store"] = register_store;
  my_functions["order"] = order;
  //my_functions['']

  function order(response) {
    if (response.redirectURL != undefined) {
      window.location.href = response.redirectURL;
    }
  }

  function createstore() {}

  function recovery(response) {
    if (response.token != undefined) {
      load_modal_view("code_confirmation", {
        token: response.token,
        new_password: true,
      }).then(function () {
        start_timer();
      });
    }
  }

  function login(response) {
    if (response.login != undefined && response.login == true) {
      window.location.href = base_url + "store";
    }
  }

  function new_password(response) {}

  var store_register = false;
  function register_store(response) {
    if (response.status == true) {
      store_register = true;
      load_modal_view("code_confirmation", {
        token: response.token,
      }).then(function () {});
    }
  }

  function register(response) {
    if (response.signup != undefined && response.signup == true) {
      load_modal_view("code_confirmation", {
        token: response.token,
      }).then(function () {});
    }
  }

  function confirmation(response) {
    if (response.confirmation != undefined && response.confirmation == true) {
      if (response.new_password == true) {
        load_modal_view("new_password", {
          token: response.token,
        });
      } else {
        if (store_register == false) {
          location.href = base_url + "?register_success";
        } else {
          location.href = "/store";
        }
      }
    } else {
      $(".code_confirmation_item").addClass("error");
    }
  }

  $("#save_btn").on('click', function(){
    loading1();
  });

  var image_index = 1;
  function addProduct(response) {
    if (response.status == true) {
      $("#mainpics").empty();
      location.href = base_url + "store";
    } else if (response.ch_id != undefined) {
      $("input[name=ch_id]").val(response.ch_id);
      if (response.img_id != undefined) {
        var myjsonD = JSON.parse(response.img_id);
        $.each(myjsonD, function (index, myjson) {
          $("#mainpics").append(
            '<div id="' +
              myjson[1] +
              '" class="pics col-4 col-md-6 col-lg-4"><input type="hidden" name="image_num[]" value="' +
              myjson[1] +
              '"/><img src="' +
              myjson[0] +
              '" alt=""><button class="image-delete" id="' +
              myjson[1] +
              '"><i class="fa fa-close"></i></button></div>'
          );
          image_index++;
        });
        $(".previewimg").remove();
        $("input[type=file]").val("");
        addNum();
      }
    }
  }

  $(document).on("click", "#code_resend.add_active_time", function () {
    $.post(
      base_url + "retry-sms",
      {
        token: $("input[name=token]").val(),
      },
      function () {
        start_timer();
      }
    );
  });

  $(document).on("keyup", ".code_confirmation_item", function () {
    $(this).select();
  });

  $(document).on("keyup", ".code_confirmation_item", function (e) {
    var index = $(this).index();
    if (index < $(".code_confirmation_item").length) {
      if ($(this).val().length == 1) {
        $(".code_confirmation_item")
          .eq(index + 1)
          .focus()
          .val("");
      } else if ($(this).val().length > 1) {
        $(this).val("");
      }
    }

    if (e.keyCode == 8) {
      if (index > 0) {
        $(".code_confirmation_item")
          .eq(index - 1)
          .focus();
      }
    }
  });

  function start_timer() {
    $(".active-timer").removeClass("add_active_time");
    var second = 60;
    var minute = 1;
    var inter = setInterval(function () {
      second--;
      if (second == 0 && minute == 0) {
        clearInterval(inter);
        $(".active-timer").addClass("add_active_time");
      } else if (second == 0) {
        minute--;
        second = 59;
        $(".active-timer").removeClass("add_active_time");
      }
      $(".timer").html(minute + " : " + second);
    }, 1000);
  }

  $(".number-button").click(function () {
    $(this).select();
  });

  $(".number-button").keyup(function (e) {
    var index = $(this).index();
    if (index < $(".number-button").length) {
      $(".number-button").mask("## ### ## ##", {
        reverse: true,
      });
      if ($(this).val().length == 9) {
        $(".number-button")
          .eq(index + 1)
          .focus()
          .val("");
      } else if ($(this).val().length > 9) {
        $(this).val("");
      }
    }

    if (e.keyCode == 8) {
      if (index > 0) {
        $(".number-button")
          .eq(index - 1)
          .focus();
      }
    }
  });

  $(document).on("click", "[data-view]", function () {
    var view = $(this).attr("data-view");
    load_modal_view(view);
    $("#form_modal").modal("show");
    return false;
  });

  $(document).on("click", "[data-favorite-id]", function () {
    $(this).find(".fa").toggleClass("fa-heart").toggleClass("fa-heart-o");
    $.post(
      base_url + "add-favorites",
      {
        product_id: $(this).attr("data-favorite-id"),
      },
      function (e) {
        notification(e, "info");
      }
    );
  });

  $(document).on("click", "[data-basket-id]", function () {
    addBasket($(this));
  });

  $(document).on("change", "[data-basket-id]", function () {
    addBasket($(this), "basket");
  });

  function addBasket(obj, com = null) {
    var color = null,
      size = null,
      amount = null;
    if ($("input[data-color]:checked").val() != undefined) {
      color = $("input[data-color]:checked").val();
    }
    if ($("input[data-size]:checked").val() != undefined) {
      size = $("input[data-size]:checked").val();
    }
    if ($("input[data-amount]").val() != undefined) {
      amount = $("input[data-amount]").val();
    }

    if (obj.attr("class").indexOf("orange") != -1) {
      com = "deleteAll";
    }

    $.post(
      base_url + "add-basket",
      {
        product_id: obj.attr("data-basket-id"),
        color: color,
        size: size,
        amount: amount,
        com: com,
      },
      function (e) {
        // location.reload();
        notification(e, "info");
        read_length();
        if (obj.attr("type") != "number") {
          if (e == 1) {
            obj.text("Səbətdə").toggleClass("orange");
          } else {
            obj.text("Səbətə at").toggleClass("orange");
          }
        }
      }
    );
  }

  $("[data-change-id] .decrease").click(function () {
    var id = $(this).parent().attr("data-change-id");
    var n = $("[data-change-id=" + id + "] input").val();
    n--;
    maxstok = $("[data-change-id=" + id + "] input").attr("max");
    if (maxstok >= n) {
      $("[data-change-id=" + id + "] input").val(n);
      addBasket($("[data-change-id=" + id + "] input"), "del");
    } else {
      alert("Stokda " + maxstok + " ədəd var");
    }
  });

  $("[data-change-id] .increase").click(function () {
    var id = $(this).parent().attr("data-change-id");
    var n = $("[data-change-id=" + id + "] input").val();
    n++;
    maxstok = $("[data-change-id=" + id + "] input").attr("max");
    if (maxstok >= n) {
      $("[data-change-id=" + id + "] input").val(n);
      addBasket($("[data-change-id=" + id + "] input"));
    } else {
      alert("Stokda " + maxstok + " ədəd var");
    }
  });

  var base_url = $("#base_url").val();

  function load_modal_view(view = "login", data = null) {
    $("#form_modal").find("a[data-view]").removeClass("active");
    $("#form_modal")
      .find("a[data-view=" + view + "]")
      .addClass("active");
    loading();

    let a = new Promise(function (myResolve, myReject) {
      $.post(
        base_url + "load-modal-view",
        {
          view: view,
          data: data,
        },
        function (e) {
          $("#form_modal").modal("show").find(".modal-body").html(e);
          loading(false);
          ajaxForm_load();
          myResolve(true);
          $("#phone").mask("(99) 999-99-99", {
            translation: {
              placeholder: "___-__-__",
            },
          });
        }
      );
    });
    return a;
  }

  function loading(com = true, obj = $("body")) {
    if (com == true) {
      obj.append('<div class="loading"></div>');
      
    } else {
      obj.find(".loading").remove();
    }
  }
  function loading1(com = true, obj = $("body")) {
    if (com == true) {
      obj.append('<div id = "div_load">\
      \
      <div id="loadingIndicator">\
      </div>\
      <div style = "width:100%; height:100%; text-align: center;">\
      <p id = "loading-p"> Şəkillər yüklənir. Xahiş edirik gözləyin</p></div></div>');
      
    } else {
      obj.find("#div_load").remove();
    }
  }

  /* window.addEventListener('scroll', function () {
        var nav = document.querySelector('nav');
        nav.classList.toggle('sticky', window.screenY > 0)
    }) */

  function start_clock(obj) {
    var year = Math.abs(obj.attr("data-year"));
    var month = Math.abs(obj.attr("data-month"));
    var day = Math.abs(obj.attr("data-day"));
    var hour = Math.abs(obj.attr("data-hour"));
    var minute = Math.abs(obj.attr("data-minute"));
    var second = Math.abs(obj.attr("data-second"));
    // alert(year+'-'+month+'-'+day+'-'+hour+'-'+minute+'-'+second);
    if (obj.attr("data-year") != undefined && year != "NaN" && year != null) {
      obj.countDown({
        targetDate: {
          day: day, // hedef gün
          month: month, // hedef ay
          year: year, // hedef yıl
          hour: hour, // hedef saat
          min: minute, // hedef dakika
          sec: second, //hedef saniye
        },
      });
    }
  }

  $.each($(".auction_timer"), function (item, value) {
    var id = $(".auction_timer").eq(item).attr("id");
    start_clock($("#" + id));
  });

  $(document).on("click", "button[data-offer],a[data-offer]", function () {
    var auction_id = $(this).attr("data-offer");
    read_offers(auction_id);
  });

  // timer
  var offer_timer = null;
  //add offer

  $(document).on("click", "#add_offer", function () {
    loading();
    $.post(
      base_url + "add-offer",
      {
        auction_id: $(this).attr("data-auction-id"),
      },
      function (e) {
        var json = JSON.parse(e);
        notification(json.text, json.type);
        loading(false);
        read_last_offers();
        get_total_balance();
      }
    );
  });

  var g_auction_id = 0;
  var g_last_offer_id = 0;
  var g_noft_id = 0;
  var g_noft_len = 0;

  function read_offers(auction_id) {
    $("#offer_modal").modal("show");
    loading();
    $.ajax({
      url: base_url + "read-offers",
      type: "post",
      dataType: "Json",
      data: {
        auction_id: auction_id,
      },
      success: function (e) {
        loading(false);
        g_auction_id = auction_id;
        g_last_offer_id = e.last_id;
        $("#offer_items").html(e.html);
        setTimeout(function () {
          offer_timer = setInterval(read_last_offers, 2000);
        }, 1000);
      },
    });
  }

  var error = false;

  function read_last_offers() {
    if (g_auction_id != 0) {
      $.ajax({
        url: base_url + "read-last-offers",
        data: {
          auction_id: g_auction_id,
          last_offer_id: g_last_offer_id,
        },
        dataType: "Json",
        type: "post",
        success: function (json) {
          $("#offer_items").find(".alert").remove();
          if (json.last_id != 0) {
            g_last_offer_id = json.last_id;
            $("#offer_items").append(json.html);
          }
        },
        error: function () {
          notification(
            "Şəbəkə xətası baş verdi. Zəhmət olmasa cihazınızın internetə qoşulu olduğunu yoxlayın.",
            "danger"
          );

          if (error == false) {
            clearInterval(offer_timer);
            error = true;
            setTimeout(function () {
              read_last_offers();
            }, 5000);
          } else {
            setTimeout(function () {
              location.reload();
            }, 5000);
          }
        },
      });
    }
  }

  //read noft
  function read_noft(is_read = false) {
    $.post(
      base_url + "read-noft",
      {
        last_noft_id: g_noft_id,
        is_read: is_read,
      },
      function (e) {
        e = JSON.parse(e);
        if (e.last_id != 0) {
          g_noft_id = e.last_id;
          if (is_read) {
            g_noft_len = e.count;
          } else {
            g_noft_len++;
          }

          if (g_noft_len != 0) {
            $(".on-numbers").show().find("span").html(g_noft_len);
          } else {
            $(".on-numbers").hide().find("span").html(g_noft_len);
          }

          $("#notifications").prepend(e.html);
        }
      }
    );
  }

  function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(";");
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == " ") {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

  $("#noft_btn").click(function () {
    $.post(
      base_url + "reading-all-noft",
      {
        id: true,
      },
      function () {
        g_noft_len = 0;
        $(".on-numbers").hide().find("span").html(g_noft_len);
        $("#notifications").find(".active").removeClass("active");
      }
    );
  });
  //end noft

  $("#offer_modal").on("hidden.bs.modal", function () {
    clearInterval(offer_timer);
  });

  //
  function get_total_balance() {
    $.post(base_url + "read-total-balance", function (e) {
      $("#total_balance").html(e);
    });
  }

  //datatable
  $(".myTable").DataTable({
    ordering: false,
    info: false,
    searching: false,
    lengthChange: false,
  });

  //is login functions
  if (getCookie("token") != "") {
    //read_noft(true);
    //setInterval(read_noft, 5000);
    //get_total_balance();
  }

  $(document).on("click", ".mycar-btn[id]", function () {
    var id = $(this).attr("id");
    $.post(
      base_url + "read-mycar-location",
      {
        id: id,
      },
      function (e) {
        $("#location_modal").modal("show").find(".modal-body").html(e);
      }
    );
  });

  $("#brand_id").change(function () {
    loading();
    $.post(base_url + "get-models", { brand_id: $(this).val() }, function (e) {
      $("#model_id").html(e);
      loading(false);
    });
  });

  $("#mainpics").sortable();
  $("#mainpics").disableSelection();
  

  function addNum() {
    //video_index
    var len = $("#mainpics .pics").length;
    $('#video_index').empty();
    for(var o=1;o<=len;o++){
        $('#video_index').append('<option value="'+o+'">'+o+'</option>');
    }

    var html = "";
    for (var i = 1; i <= len; i++) {
      if (i == 1){
        html += '<div class = "col-lg-12 col-12" id = "div_'+i+'" style = "display: block;">'; 
        html +='<input id = "input_'+i+'" type="text" name="video_url[]" placeholder="http://www" value="" style = ""/>';
        html +='</div>';
      }
      else {
        html += '<div class = "col-lg-12 col-12" id = "div_'+i+'" style = "display: none;">'; 
        html +='<input id = "input_'+i+'" type="text" name="video_url[]" placeholder="http://www" value="" />';
        html += '</div>';
      }      
    }
    var myDiv = document.getElementById('youtube_div');
    myDiv.innerHTML = html;
  }


$('#video_index').change(function(){
  
  var selectedValue = $(this).val();

  const divsWithDisplayBlock = $("#youtube_div").find("div[style*='display: block']");
  
  divsWithDisplayBlock.css('display', 'none');

    var div = document.getElementById("div_"+selectedValue);
    div.style.display = 'block';
})


  $(document).on("change", "input[type=file]", function (event) {
    var multiple = $(this).prop("multiple");
    var data_preview_id = $(this).attr("data-preview-id");
    var input = $(event.currentTarget);
    var files = input[0].files;
    console.log(files);
    //  $('#' + data_preview_id).find('.pics:not([id])').remove();
    // alert(files);
    imageindex = [];
    
    function readImagesInOrder(files) {
      var index = 0;
    
      function readNextImage() {
        if (index >= files.length) {
          // All images have been read
          return;
        }
    
        var file = files[index];
        var reader = new FileReader();
    
        reader.onload = function (e) {
          var image_base64 = e.target.result;
    
          image_base64 = e.target.result;
          // alert(image_base64);
          if (multiple) {
            val++;
            var h = $("#imageHeight").width();
            var w = $("#imageHeight").width();
            // $("#" + data_preview_id).css('height', h);

            $("#" + data_preview_id).append(
              '<div class="pics previewimg col-4 col-md-4 col-lg-4" style = "height: '+ h+'px;">\
              <input type="hidden" name="image_index[]" value="'+(index+1)+'">          \
              <img calss="img-fluid1" name="image[]" src="' +
                image_base64 +
                '" alt=""><button class="image-delete" id="' +
                (index+1) + 
                '"><i class="fa fa-close"></i></button></div>'
            );
          } else {
            $("#" + data_preview_id).attr("src", image_base64);
          }
          index++;
          readNextImage();
        };
    
        reader.readAsDataURL(file);
      }
    
      // Start reading the first image
      readNextImage();
    }
    readImagesInOrder(files);
    // var val = 0;
    // for (var i = 0; i < files.length; i++) {
    //   var file = files[i];
    //   var reader = new FileReader();
    //   reader.onload = function (e) {
    //     image_base64 = e.target.result;
    //     // alert(image_base64);
    //     if (multiple) {
    //       val++;
    //       var h = $("#imageHeight").width();
    //       var w = $("#imageHeight").width();
    //       // $("#" + data_preview_id).css('height', h);

    //       $("#" + data_preview_id).append(
    //         '<div class="pics previewimg col-4 col-md-4 col-lg-4" style = "height: '+ h+'px;">\
    //         <input type="hidden" name="image_index[]" value="'+i+'">          \
    //         <img calss="img-fluid1" name="image[]" src="' +
    //           image_base64 +
    //           '" alt=""><button class="image-delete" id="' +
    //           i + 
    //           '"><i class="fa fa-close"></i></button></div>'
    //       );
    //     } else {
    //       $("#" + data_preview_id).attr("src", image_base64);
    //     }
    //   };
    //   reader.readAsDataURL(file);
    // }

    setTimeout(function () {
      addNum();
    }, 500);

    $("#mainpics").sortable();
    $("#mainpics").disableSelection();
    /*  $( ".pics" ).disableSelection(); */
    // setTimeout(function(){ $('#add_product').submit();},500);
  });

  

  $(document).on("click", ".delete", function () {

    $(this).parent().remove();
    return false;
  });

  $(".paid-on-one,.paid-on-year").click(function () {
    $(".after-focus").removeClass("active");
    $(this).find(".after-focus").addClass("active");
    $(this).find("input[type=radio]").prop("checked", true);
  });

  $(document).on("click", ".terms a", function () {
    $("#terms_modal").modal("show");

    return false;
  });

  $("#addSize").click(function () {
    var d = $(".size_input").eq(0).clone();
    $("#sizes").append(d);
    return false;
  });

  $("#addColor").click(function () {
    var dd = $(".color_input").eq(0).clone();
    $("#colors").append(dd);
    return false;
  });

  $(".mobile-tabs a").click(function () {
    $(".mobile-tabs a").removeClass("active");
    $(this).addClass("active");
  });

  $(".modal").modal({
    backdrop: "static",
    keyboard: true,
    show: false,
  });

  if ($("#register_success").length > 0) {
    $("#register_success").modal("show");
    setTimeout(function () {
      $("#register_success").modal("hide");
    }, 2000);
  }

  autosize($(".text-area"));

  var comission = Math.abs($("#price").attr("data-comission"));
  var courier = Math.abs($("#price").attr("data-courier"));
  var val =
    Math.abs($("#price").val()) +
    (Math.abs($("#price").val()) * comission) / 100 +
    courier;
  $("#totalprice").val(val);

  $("#price").keyup(function () {
    var comission = Math.abs($(this).attr("data-comission"));
    var courier = Math.abs($(this).attr("data-courier"));
    var val =
      Math.abs($(this).val()) +
      (Math.abs($(this).val()) * comission) / 100 +
      courier;
    $("#totalprice").val(val);
  });

  $("#totalprice").keyup(function () {
    var comission = Math.abs($(this).attr("data-comission"));
    var courier = Math.abs($(this).attr("data-courier"));
    var val =
      Math.abs($(this).val()) -
      (Math.abs($(this).val()) * comission) / 100 -
      courier;
    $("#price").val(val);
  });

  $(document).on("click", ".image-delete[id]", function (e) {

    var id = $(this).attr('id');

    
    var obj = document.getElementById("div_" + $(this).attr("id"));
    obj.remove();
    var index = $(this).attr('delta_index');

    if(index==1){
      
      var id1 = $('.image-delete[delta_index="2"]').attr('id');
      // alert(id1);
      obj = document.getElementById("div_" + id1);
      obj.style.display = "block";
      // obj.css('display', 'block');
    }

    $('#video_index option').filter(function() {
      return $(this).val() === id;
    }).remove();

    $('#video_index option').each(function(index) {
      $(this).text(index+1);
    });
   
    
    image_delete($(this));
    return false;
  });

  $(document).on("mousedown", ".image-delete[id]", function () {
    // alert(e);
    // image_delete($(this));

    return false;
  });

  function image_delete(obj) {
    $.post(
      base_url + "store/delete_image",
      { id: obj.attr("id") },
      function (e) {
        console.log(e);
       
      }
    );
    obj.parent().remove();
  }

  $(document).on("click", ".dsad", function () {
    var obj = $(this);
    obj.remove();
    return false;
  });

  $("#category").change(function (e) {
    $.post(
      base_url + "read-category/" + $(this).val(),
      { id: $(this).val() },
      function (e) {
        if (e != "") {
          $("#sub_div").show();
          $("#subcategory").html(e);
          
        } else {
          $("#subcategory").html('<option value="0">--seçim--</option>');
          // $("#category").attr("name", "category[]");
          $("#sub_div").hide();
          $("#sub_child_div").hide();
          // $("#subchildcategory").attr("name", "").empty();
          $("#subchildcategory").html('<option value="0">--seçim--</option>');
        }
      }
    );
  });

  $("#subcategory").change(function (e) { 
    $.post(
      base_url + "read-category/" + $(this).val(),
      { id: $(this).val() },
      function (e) {

        if (e != "") {
          $("#sub_child_div").show();
          $("#subchildcategory").html(e);

        } else {
          $("#subchildcategory").html('<option value="0">--seçim--</option>');
          // $("#category").attr("name", "category[]");
          $("#sub_child_div").hide();
        }
      }
    );
  });

  function read_length() {
    $.post(base_url + "basket/read-length", {}, function (e) {
      $(".basket_len").html(e);
    });
  }



  $(".center-button").click(function () {
    $("input[name=search]").focus();
    $(document).css("scrollTop", 0);
  });

});

$(document).ready(function(){
  var width = $('.slick-active').width();
  $('.firstpic .slick-active').css('height', width);
  width = $('.product-thumb-item').width();
  $('.product-thumb-item').css('height', width);
});

$(window).ready(function(){
  var width = $('.slick-active').width();
  $('.firstpic .slick-active').css('height', width);
  width = $('.product-thumb-item').width();
  $('.product-thumb-item').css('height', width);

  // $('.your-carousel').on('afterChange', function(event, slick, currentSlide) {
  //   // The 'afterChange' event is triggered when the active slide changes
    
  //   // Get the currently active slide
  //   var $activeSlide = $(slick.$slides.get(currentSlide));
    
  //   // Check if the active slide has the '.slick-active' class
  //   if ($activeSlide.hasClass('slick-active')) {
  //     // Handle the change event for '.slick-active' slide here
  //     console.log('Active slide changed!');
  //   }
  // });
});

$(window).resize(function(){
  var width = $('.slick-active').width();
  $('.firstpic .slick-active').css('height', width);
  width = $('.product-thumb-item').width();
  $('.product-thumb-item').css('height', width);
});

$(document).on('click', '.slick-next', function(){
  var width = $('.slick-active').width();
  $('.firstpic .slick-active').css('height', width);
  width = $('.product-thumb-item').width();
  $('.product-thumb-item').css('height', width);
})
$(document).on('click', '.slick-prev', function(){
  var width = $('.slick-active').width();
  $('.firstpic .slick-active').css('height', width);
  width = $('.product-thumb-item').width();
  $('.product-thumb-item').css('height', width);
})
$('.firstpic-item').on('mousemove', function(event){
  // Handle mousemove event here
  var width = $('.slick-active').width();
  $('.firstpic .slick-active').css('height', width);
  width = $('.product-thumb-item').width();
  $('.product-thumb-item').css('height', width);

});

$(document).ready(function(){
  var base_url = $("#base_url").val();
  var page = 1;
  var loading = false;
  var prepage = 1;
  var flag = false;
  var order_page = 1;
  var products_page= 1;
  var preproducts_page = 1;

  function getData(){
    // if(!flag){
      if (!loading) {
        loading = true;
        
        prepage = page;
        $.post(
          base_url + "get_page_product_ctrl",
          {
            page: ++page
          },
        ).done(function(response) {
          // Handle the success response           
          var result = JSON.parse(response);
          console.log('page: '+ page);
          $("#pmy").addClass('loading-hidden');
          if (result.result == ""){
            page = prepage;
          }
          if (result.page == 1) {
            
            loading = false;
            return;
          }
          
          var mydiv = document.getElementById('home_product');
          var html = mydiv.innerHTML;
          mydiv.innerHTML = html + result.result;
          loading = false;
        })
        .fail(function(xhr, status, error) {
          // Handle the error response
          $("#pmy").addClass('loading-hidden');
          loading = false;
          page = prepage;
        });;        
      // }
    }
  }

  function getData_search(){
    if(!flag){
      if (!loading) {
        loading = true;
        
        prepage = page;
        console.log(base_url + "search/search_page");
        $.post(
          base_url + "search/search_page",
          {
            page: ++page,
            search: $('#searchbox').val()

          },
        ).done(function(response) {
          // Handle the success response    
          console.log(response)       ;
          var result = JSON.parse(response);
          console.log('page: '+ page);
          // if (result.result == ""){
          //   page = prepage;
          // }
          $("#pmy").addClass('loading-hidden');
          if (result.page == 1) {
            
            loading = false;
            return;
          }
          
          var mydiv = document.getElementById('searchview');
          var html = mydiv.innerHTML;
          mydiv.innerHTML = html + result.result;
          loading = false;
        })
        .fail(function(xhr, status, error) {
          // Handle the error response
          $("#pmy").addClass('loading-hidden');
          loading = false;
          page = prepage;
        });;        
      }
    }
  }

  function productsPage() {

    // Find the active button's href attribute value
    var activeHref = $('.mychildtab a.active').attr('href');

    // Check if an active button was found
    if (activeHref) {
      // The active button's href attribute value was found
      // console.log("-----------:", activeHref);
      var url = "";
      if(activeHref == base_url+"store"){
        url = base_url + 'scroll/products_page';
      }
      else if (activeHref == base_url+"/store?list=stok") {
        url = base_url + 'scroll/products_page?list=stok';
      }
      else if (activeHref == base_url+"store?list=waiting") {
        url = base_url + 'scroll/products_page?list=waiting';
      }
       

        loading = true;

        preproducts_page = products_page;
        $.post(
          url,
          {
            page: ++products_page,
          },
        ).done(function(response) {
          // Handle the success response    
          console.log(response);       
          var result = JSON.parse(response);
          console.log('page: '+ products_page);
          console.log(result);
          $("#pmy").addClass('loading-hidden');
          if (result.result == ""){
            // products_page = preproducts_page;
            loading =false;
            return;
          }
  
          if (result.page == 1) {
            
            loading = false;
            return;
          }

          $('#store_products_table').append(result.result);
          loading = false;
        })
        .fail(function(xhr, status, error) {
          // Handle the error response
          $("#pmy").addClass('loading-hidden');
          loading = false;
          products_page = preproducts_page;
          
        });
      // }
    } else {
      // No active button found
      console.log("No active button found");
    }
  }

    
  

    function orderPage(){
        // Find the active button's href attribute value

            loading = true;
            var url = base_url + 'store/orders_page/';
            console.log(url);
            var date_start = $('#date_start').val();
            var date_end = $('#date_end').val();

            preproducts_page = products_page;
            $.post(
              url,
              {
                page: ++products_page,
                start: date_start,
                end: date_end,
              },
            ).done(function(response) {
              console.log(response);
              var result = JSON.parse(response);
              $("#pmy").addClass('loading-hidden');
              if (result.result == ""){
                // products_page = preproducts_page;
                loading =false;
                return;
              }

              if (result.page == 1) {
                
                loading = false;
                return;
              }
              
              $('#store_order_table').append(result.result);
              loading = false;
            })
            .fail(function(xhr, status, error) {
              // Handle the error response
              $("#pmy").addClass('loading-hidden');
              loading = false;
              products_page = preproducts_page;
              
            });       
    }

    function balancePage(){
        // Find the active button's href attribute value
            loading = true;
            var url = base_url + 'store/orders_page/';
            console.log(url);
            var date_start = $('#date_start').val();
            var date_end = $('#date_end').val();

            preproducts_page = products_page;
            $.post(
              url,
              {
                page: ++products_page,
                start: date_start,
                end: date_end,
              },
            ).done(function(response) {
              console.log(response);
              var result = JSON.parse(response);
              $("#pmy").addClass('loading-hidden');
              if (result.result == ""){
                // products_page = preproducts_page;
                loading =false;
                return;
              }

              if (result.page == 1) {
                
                loading = false;
                return;
              }
              

              $('#store_order_table').append(result.result);
              loading = false;
            })
            .fail(function(xhr, status, error) {
              // Handle the error response
              loading = false;
              products_page = preproducts_page;
              
            });       
    }

    function categoryPage(){
        // Find the active button's href attribute value
            loading = true;
            var url = base_url + 'category/page/';
            console.log(url);
           

            preproducts_page = products_page;
            $.post(
              url,
              {
                page: ++products_page,
                category_name : $('#category_page_id').val(),               
              },
            ).done(function(response) {
              console.log(response);
              var result = JSON.parse(response);
              $("#pmy").addClass('loading-hidden');
              console.log(result.page);
              if (result.result == ""){
                // products_page = preproducts_page;
                loading =false;
                return;
              }

              if (result.page == 1) {
                
                loading = false;
                return;
              }
              

              $('#category_page').append(result.result);
              loading = false;
            })
            .fail(function(xhr, status, error) {
              // Handle the error response
              loading = false;
              // products_page = preproducts_page;
              
            });
    }


   // Scroll event listener
   $(window).scroll(function() {
      var footerheight = $('#footer').height();
      // console.log(footerheight);
      if ($(window).scrollTop() + $(window).height() >= $(document).height() - footerheight) { 
        if(!flag){          
          
          // Find the active button's href attribute value
          var activeHref = $('.account-menu a.active').attr('href');

          // Check if an active button was found
          if (activeHref) {

            if(activeHref == base_url + "store/") {
              $("#pmy").removeClass('loading-hidden');
              productsPage();
            }
            else if (activeHref == base_url + "store/orders/") {
              $("#pmy").removeClass('loading-hidden');
              orderPage();
            }
            else if (activeHref == base_url + "store/balance") {
              $("#pmy").removeClass('loading-hidden');
              balancePage();
            }

            // The active button's href attribute value was found
            console.log("Active button's href:", activeHref);
          } 
          else {
            // No active button found
            console.log("No active button found");
          }
          var mydiv = document.getElementById('home_product');
          if(mydiv !=null) 
          {
            $("#pmy").removeClass('loading-hidden');
            getData(); // Fetch more data when scroll position is near the bottom
          }
          mydiv = document.getElementById("searchview");
          if(mydiv !=null) {    
            $("#pmy").removeClass('loading-hidden');       
            getData_search(); 
          }// Fetch more data when scroll position is near the bottom
          mydiv = document.getElementById("category_page");
          if(mydiv !=null) {    
            $("#pmy").removeClass('loading-hidden');       
            categoryPage(); 
          }// Fetch more data when scroll position is near the bottom
        }
        
          flag = true;
      }
      else {
        flag = false;
      }
  });
});

