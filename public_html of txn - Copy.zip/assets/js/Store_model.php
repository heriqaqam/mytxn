<?php

class Store_model extends CI_Model{
    function __construct() {
        parent::__construct();
        
        $this->load->model('front/front_database_model');
        $this->load->model('front/users_model');
    }


    public function delete_cache(){
        global $store;
        if($store!=false){
            $sql="delete from products where store_id=".$store['id']." and title='' and category=0";
            $this->front_database_model->front_query($sql);
        }
    }

    public function get_store($user_id){

        $store=$this->front_database_model->front_read_row('stores',array('user_id'=>$user_id));
        if(count($store)>0){
            return $store;
        }
        else{
            return false;
        }

    }
    

    public function add_product($data){
        $this->load->model('front/users_model');
        global $store;
        global $user;
        if($user and $store){
            $ar=array_merge($data,array('store_id'=>$store['id']));
            return $this->front_database_model->front_insert('products',$ar);
            
        }
        else{
            return false;
        }
    }


    public function delete_product($product_id){
        global $user;
        global $store;
        if($store){
            $check=$this->front_database_model->front_read_row('products',array('store_id'=>$store['id'],'product_id'=>$product_id));
            if(count($check)>0){
                $this->front_database_model->front_delete('products',array('id'=>$check['id']));
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }


    public function edit_product($product_id,$ar){
        global $store;
        if($store){
            $check=$this->front_database_model->front_read_row('products',array('store_id'=>$store['id'],'id'=>$product_id));
            if(count($check)>0){
               
                $this->front_database_model->front_update('products',$ar,array('id'=>$check['id']));
                return true;
            }
            else{
                return false;
            }
        }
    }


   

    public function get_products($com=true){
       global $store;
       global $user;
        if($store and $user){

            $list=$this->input->get("list");

            $where=array('store_id'=>$store['id']);

            if(!empty($list) and $com){
                if($list=='stok'){
                    $where['stok']=0;
                
                }
                else if($list=='waiting'){
                    $where['share']='false';
                }
            }
            else if($com){
                $where['stok!=']=0;
                $where['share']='true';
            }
            /* print_r($where);die; */
            $products=$this->front_database_model->front_read('products',$where);
           /*  print_r($products); */
            if(count($products)>0){
                return $products;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }

    public function read_orders($refunds='false'){
        global $store;
        $start  =$this->input->get('start',true);
        $end    =$this->input->get('end',true);
        if($store){
            $where=array('store_id'=>$store['id'],'refund'=>$refunds);
            if(!empty($start)){
                $where['date>=']=$start;
            }
            else if(!empty($end)){
                $where['date<=']=$end;
            }

          //  print_r($where);die;

            $orders=$this->front_database_model->front_read('orders',$where);
            if(count($orders)>0){
                return $orders;
            }
            else{
                return false;
            }
        }
        return false;
    }


    public function stores_payed(){
        global $store;
        if($store){
            $results=$this->front_database_model->front_read('stores_payed',array('store_id'=>$store['id']));
            $total=0;
            foreach($results as $r){
                $total+=$r['price'];
            }
            return $total;
        }
        else{
            return 0;
        }
    }


    public function delete_image($image_id){
        global $store;
        $check=$this->front_database_model->front_read_row('products_image',array('id'=>$image_id));
        if(count($check)>0){
            $product=$this->home_model->get_product($check['product_id']);
            if($product['store_id']==$store['id']){
                $this->front_database_model->front_delete('products_image',array('id'=>$image_id));
            }
        }
    }

}

?>