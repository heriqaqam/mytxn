$(function () {

    var controller = window.location.href.split("/")[4];
    var edit_link = controller.split("#");
    controller = edit_link[0];
    var base_url = $('#base_url').val() + 'admin/';
    //notification
    function show_noft(type, text) {
        var icon = '';
        switch (type) {
            case 'info':
                icon = 'info';
                break;
            case 'warning':
                icon = 'warning';
                break;
            case 'danger':
                icon = 'error';
                break;
            case 'success':
                icon = 'done_outline';
                break;
        };
        $.notify({
            icon: icon,
            message: text
        }, {
            type: type,
            timer: 1000,
            placement: {
                from: 'bottom',
                align: 'center'
            }
        });
    };
    var lang_id = 0;
    $('.header_lang_btn button').click(function () {
        lang_id = $(this).attr('id');
        $(this).parent().find('button').removeClass('btn-info').addClass('btn-primary');
        $(this).removeClass('btn-primary').addClass('btn-info');
        $('#' + controller).find('tr:not([data-lang=' + lang_id + '])').hide();
        $('#' + controller).find('tr[data-lang=' + lang_id + ']').show();
    })
    //image preview
    function write_option(selected = 0) {
        var option = '';
        for (i = 1; i < 10; i++) {
            var sel = '';
            if (selected == i) {
                sel = 'selected';
            }
            option += '<option ' + sel + ' value="' + i + '">' + i + '</option>';
        }
        return option;
    }

    var i = 0;
    $.fn.write_image = function (src, selected = 0, btn_id = 0) {
        i++;
        $(this).append('<div class="form-image-item"><select class="image_num" name="image_num[]">' + write_option(selected) + '</select><button data-image-id="' + btn_id + '"><i class="material-icons">close</i></button><img src="' + src + '"/></div>');

    }

    $(document).on('click', '.form-image-item button[data-image-id]', function () {
        var image_obj = $(this).parent();
        var id = $(this).attr('data-image-id');
        if (id != 0) {
            $.post(base_url + controller + '/delete_image', {
                'id': id
            }, function () {
                image_obj.remove();
            })
        } else {

        }
        return false;
    })
    //


    $(document).on('change', "input[type=file]", function (event) {

        var multiple = $(this).prop('multiple');

        $(this).parent().find('.custom-file-label').text($(this).val());
        var obj = $(this).parent().parent().parent().find('.form-image');
        var input = $(event.currentTarget);
        var files = input[0].files;

        for (var i = 0; i < files.length; i++) {
            file = files[i];
            var reader = new FileReader();
            reader.onload = function (e) {
                image_base64 = e.target.result;
                if (multiple) {
                    obj.write_image(image_base64);
                } else {
                    obj.attr('src', image_base64);
                }
            };
            reader.readAsDataURL(file);
        }

    });
    //ajax not refresh form function
    var lm = 0;
    var agent_button = true;

    function set_ajaxform() {
        $('form:not([data-stop])').ajaxForm({
            beforeSend: function () {
                $('#modal_progress').show().find('.progress-bar').removeAttr('style');
                $('[data-modal]').prop('disabled', true);
            },
            uploadProgress: function (h, o, t, faiz) {
                $('#modal_progress>.progress-bar').css('width', faiz + '%').html(faiz + ' %');
            },
            complete: function (x) {
                $('[data-modal]').prop('disabled', false);
                $(document).find('title').text('Correct Technology');
                if (x.responseText == 'ok') {
                    show_noft('success', 'Yükləndi');
                    read(lm);
                    location.reload();
                    
                    if (agent_button == true) {
                        $('.modal').modal('hide');
                        reset_form();
                    } else {
                        agent_button = true;
                    }

                } else {
                    show_noft('danger', x.responseText);
                }
                $('#modal_progress').hide();
            }
        });
    }
    set_ajaxform();
    //ajax data read for content
    function ajax_read(url, data, obj) {
        $.ajax({
            type: 'post',
            url: base_url + url,
            dataType: 'json',
            data: data,
            success: function (e) {
                obj.html(e.content);
                if (lang_id != 0) {
                    obj.find('tr:not([data-lang=' + lang_id + '])').hide();
                }
                $('.page-loading').hide();
            }

        })
    };
    //ajax read data function for form
    function ajax_post(url, data, refresh = false) {
        $.ajax({
            type: 'post',
            url: base_url + url,
            dataType: 'json',
            data: {
                'id': data
            },
            success: function (e) {
                if (refresh == true) {
                    read(lm);
                    show_noft('info', e.msg);
                } else {
                    //
                    write_form(e);
                    //
                }
            }
        })
    };


    function write_form_element(object, item, value) {

        if (object.find('[name=' + item + ']:not([type=file])').length > 0) {

            if (object.find('[name=' + item + '].word').length > 0) {
                object.find('[name=' + item + '].word').froalaEditor('html.set', value);
            }

            if (object.find('[name=' + item + ']').attr('type') != undefined) {
                if (object.find('[name=' + item + ']').attr('type') == 'checkbox' || object.find('[name=' + item + ']').attr('type') == 'radio') {
                    if(value=='false' || value==false){
                        object.find('[name=' + item + ']').prop('checked', false);
                    }
                    else{
                        object.find('[name=' + item + ']').prop('checked', true);
                    }
                   
                } 
                else {
                    if(item != 'parent_id'){
                        object.find('[name=' + item + ']').val(value);
                    } 
                    // alert(":-> "+object + " : "+ item + " : " + value);
                   
                }
            } else {
                // alert("____: "+object + " : "+ item + " : " + value);
                object.find('[name=' + item + ']').val(value);
            }
        } else {
            if (item == 'image') {
                if (object.find('img.form-image').length > 0) {
                    object.find('img.form-image').attr('src', value);
                } else {
                    object.find('.form-image').html(value);
                }
            }
        }
    }

    var my_functions = new Object();
    my_functions['auctions'] = $('#' + controller + '_panel').auctions;
    my_functions['lang_settings']=lang_settings;
    my_functions['edit_product']=edit_product;
    // my_functions['settings_category']=settigs_category;

    //write form function
    function write_form(e) {
        var object = $('#' + controller + '_panel');
        object.find('input[name=ch_id]').val(e.id);
        var object2 = $('#' + controller + '_settings');

        $.each(e, function (item, value) {
            // alert(item + " : "+ value);
            if (item == 'res_type') {
                my_functions[value](e);
            }

            write_form_element(object, item, value);
            write_form_element(object2, item, value);

        })

        convert_title();
        convert_description();
    }
    //lang settings
    function lang_settings(e){
        $.each(e.value,function(item,value){
            $('#l'+item).val(value);
        })
    }

    function edit_product(e){
       window.open(e.redirect_url,'_blank');
    }
    //form all element reset function
    function reset_form() {
        var object = $('#' + controller + '_panel');
        object.find('input:not([type=hidden]):not([type=checkbox]):not([type=radio])').val('');
        object.find('textarea').val('');
        object.find('input[name=ch_id]').val(0);
        object.find('.form-image').removeAttr('src');
    }

    //modal save button
    $(document).on('click', 'button[data-modal=ok]:not([disabled])', function () {
        var parent_id = $(this).attr('data-id');
        $('#' + parent_id).find('form').submit();
    });
    /* $(document).keyup(function(e){
        if(e.keyCode==192){
            agent_button=false;
            $('#'+controller+'_panel').find('form').submit();
        }
    }) */
    //page content read function 

    function read(data = {}) {
        $('.page-loading').show();
        ajax_read(controller + '/read/', data, $('#' + controller));
    }

    $('#filter_start,#filter_end').change(function () {
        data = {
            'start': $('#filter_start').val(),
            'end': $('#filter_end').val()
        }
        read(data);
    })

    $('.car_parameter_button a').click(function(){
        read({'type':$(this).attr('id')});
        $('.pagination .active').removeClass('active');
        $(this).parent().addClass('active');
        return false;
    })

    $('#page_change').change(function () {
        read($(this).val());
    })

    if (controller != 'dashboard' && controller != 'settings' && controller != 'account/profile') {
        read();
    }
    //delete function
    function del(id) {
        ajax_post(controller + '/delete', id, true);
    };
    //delete button
    var del_id = 0;
    $(document).on('click', '#' + controller + ' .btn-danger[id]', function () {
        del_id = $(this).attr('id');
        $('#delete_panel').modal('show');
    })
    //table check input array
    function check_input_array() {
        var ar = $('#' + controller + ' input[type=checkbox][id]:checked');
        var id_ar = Array(ar.length);
        for (var i = 0; i < ar.length; i++) {
            id_ar[i] = ar.eq(i).attr('id');
        }
        return id_ar;
    }
    //all delete button
    $(document).on('click', '#alldelete', function () {
        del_id = check_input_array();
        if (del_id.length > 0) {
            $('#delete_panel').modal('show');
        } else {
            show_noft('warning', 'Silmək istədiyiniz sətirləri seçin!');
        }
        return false;
    })
    //confirim delete
    $('#delete_panel .btn-danger').click(function () {
        $('.modal').modal('hide');
        del(del_id);
    })
    //edit button
    $('#' + controller + '_panel').modal({
        backdrop: 'static',
        keyboard: true,
        show: false
    });
    //edit button
    $(document).on('click', '#' + controller + ' .btn-warning[id]', function () {
        ajax_post(controller + '/read_row', $(this).attr('id'));
        $('#' + controller + '_panel').modal('show');
    })

    if (edit_link[1] != undefined && edit_link[1] != 0) {
        setTimeout(function () {
            ajax_post(controller + '/read_row', edit_link[1]);
            $('#' + controller + '_panel').modal('show');
        }, 500)
    }
    //copy button
    $(document).on('click', '#' + controller + ' .btn-info[id]', function () {
        ajax_post(controller + '/copy_row', $(this).attr('id'), true);
    })
    //all copy button
    $(document).on('click', '#allcopy', function () {
        var copy_id = check_input_array();
        if (copy_id.length > 0) {
            ajax_post(controller + '/copy_row', copy_id, true);
        } else {
            show_noft('warning', 'Kopyalamaq istədiyiniz sətirləri seçin!');
        }
    })
    //settings button
    $(document).on('click', '#' + controller + ' .btn-primary[id]', function () {
        // alert(controller);
        ajax_post(controller + '/read_row', $(this).attr('id'));
        $('#' + controller + '_settings').modal('show').find('input[name=ch_id]').val($(this).attr('id'));

    })
    //info button
    $(document).on('click', '#' + controller + ' .btn-success[id]', function () {
        id = $(this).attr('id');
        ajax_read(controller + '/read_info', {
            'id': id
        }, $('#' + controller + '_info .modal-body'));
        $('#' + controller + '_info').modal('show');
        setTimeout(function () {
            set_ajaxform();
        }, 1000);
    })
    //all settings button
    $(document).on('click', '#allsettings', function () {
        id_ar = check_input_array();
        if (id_ar.length > 0) {
            $('input[name=ch_id]').val(id_ar);
            $('#' + controller + '_settings').modal('show');
        } else {
            show_noft('warning', 'Tənzimləmək istədiyiniz sətirləri seçin!');
        }
    })

    //page title length
    $('input[name=title]').focusout(function () {
        if ($(this).val() != '') {
            $.post(base_url + 'url', {
                'title': $(this).val()
            }, function (e) {
                $('input[name=url_tag]').val(e);
            })
        }
    })

    //seo title convert 
    var text_length;
    var text_obj;

    function convert_title() {
        text_obj = $('input[name][data-title]');
        if (text_obj.val() != undefined) {
            text_length = text_obj.val().length;
            if (text_length == 0) {
                $('#page_title').hide();
            } else if (text_length <= 63) {
                $('#page_title').show().text(text_length);
            } else {
                $('#page_title').show().html('<u style="color:red">' + text_length + '<u>');
            }
        }
    }
    convert_title();

    //seo description
    function convert_description() {
        text_obj = $('input[name][data-description],textarea[name][data-description]');
        if (text_obj.val() != undefined) {
            text_length = text_obj.val().length;
            if (text_length == 0) {
                $('#page_description').hide();
            } else if (text_length <= 160) {
                $('#page_description').show().text(text_length);
            } else {
                $('#page_description').show().html('<u style="color:red">' + text_length + '<u>');
            }
        }
    }
    convert_description();


    $(document).on('change', 'input[name][data-title]', function () {
        convert_title();
    })
    $(document).on('change', 'input[name][data-description],textarea[name][data-description]', function () {
        convert_description();
    })

    //message detele functions
    $(document).on('click', '.message-btn[id]', function () {
        ajax_post('account/delete_message', $(this).attr('id'), true);
        show_noft('danger', 'Mesaj silindi!');
        $(this).parent().parent().remove();
    })

    /*table all check functions */
    $(document).on('change', '.table input', function () {
        $(this).parent().parent().parent().toggleClass('number-active');
    })
    $(document).on('change', '#all_check', function () {
        var com = $(this).prop('checked');
        for (var i = 0; i < $('.table input[id]').length; i++) {
            $('.table input[id]:eq(' + i + ')').prop('checked', com).parent().parent().parent().toggleClass('number-active');
        }
    })




    ///read dashboard
    if (controller == 'dashboard') {
        read_dashboard($('input[name=start]').val(), $('input[name=end]').val());
    }

    $('#read_dashboard_metrics').click(function () {
        read_dashboard($('input[name=start]').val(), $('input[name=end]').val());
    })


    function read_dashboard(start = '', end = '') {
        $('.page-loading').show();
        $.ajax({
            type: 'post',
            url: base_url + 'dashboard/read',
            dataType: 'json',
            data: {
                'start': start,
                'end': end
            },
            success: function (e) {
                start_chart(e);
                $('.page-loading').hide();
            }

        })
    }



    $(document).on('click','button[data-offer-id]',function(){
        var id=$(this).attr('data-offer-id');
        $('button[data-offer-id]').removeClass('btn-success');
       $(this).removeClass('btn-default').addClass('btn-success');
        $.post(base_url+controller+'/auction_sale',{'id':id},function(e){

        })
    })



    function start_chart(json) {

        var n = 200;
        var days = Array();
        var users = Array();
        var newusers = Array();
        var organicSearches = Array();
        var pageviews = Array();
        var newusers_length = 0;
        var users_length = 0;
        var pageviews_length = 0;

        max_users = 0;
        max_newusers = 0;
        max_pageviews = 0;
        max_organicSearches = 0;


        $.each(json.chart, function (key, value) {
            days.push(value.dimensions.day);
            users.push(value.metrics.users);
            newusers.push(value.metrics.newUsers);
            organicSearches.push(value.metrics.organicSearches);
            pageviews.push(value.metrics.pageviews);

            users_length += Math.abs(value.metrics.users);
            newusers_length += Math.abs(value.metrics.newUsers);
            pageviews_length += Math.abs(value.metrics.pageviews);

            if (max_newusers < value.metrics.newUsers) {
                max_newusers = value.metrics.newUsers;
            }
            if (max_users < value.metrics.users) {
                max_users = value.metrics.users;
            }
            if (max_organicSearches < value.metrics.organicSearches) {
                max_organicSearches = value.metrics.organicSearches;
            }
            if (max_pageviews < value.metrics.pageviews) {
                max_pageviews = value.metrics.pageviews;
            }

        })

        max_newusers += 20;
        max_users += 20;
        max_organicSearches += 20;
        max_pageviews += 20;

        $('#users_length').html(users_length);
        $('#newusers_length').html(newusers_length);
        $('#pageviews_length').html(pageviews_length);

        /*day list */

        chart_data = {
            labels: days,
            series: [newusers]
        };

        chart_data_settings = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: max_newusers,
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
        }

        var newusers_chart = new Chartist.Line('#newusers_chart', chart_data, chart_data_settings);
        md.startAnimationForLineChart(newusers_chart);


        chart_data = {
            labels: days,
            series: [users]
        };

        chart_data_settings = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: max_users,
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
        }

        var users_chart = new Chartist.Line('#users_chart', chart_data, chart_data_settings);
        md.startAnimationForLineChart(users_chart);

        chart_data = {
            labels: days,
            series: [organicSearches]
        };

        chart_data_settings = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: max_organicSearches,
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
        }

        var organigsearch_chart = new Chartist.Line('#organigsearch_chart', chart_data, chart_data_settings);
        md.startAnimationForLineChart(organigsearch_chart);



        chart_data = {
            labels: days,
            series: [organicSearches]
        };
        var chart_data_settings = {
            axisX: {
                showGrid: false
            },
            low: 0,
            high: max_pageviews,
            chartPadding: {
                top: 0,
                right: 5,
                bottom: 0,
                left: 0
            }
        };
        var responsiveOptions = [
            ['screen and (max-width: 640px)', {
                seriesBarDistance: 5,
                axisX: {
                    labelInterpolationFnc: function (value) {
                        return value[0];
                    }
                }
            }]
        ];
        var pageviews_chart = Chartist.Bar('#pageviews_chart', chart_data, chart_data_settings, responsiveOptions);

        //start animation for the Emails Subscription Chart
        md.startAnimationForBarChart(pageviews_chart);

        var days = Array();
        var days_html = Array();

        var html = '';
        $.each(json.data, function (key, value) {
            var index = days.indexOf(value.dimensions.day);

            $.each(value.dimensions, function (key, value) {
                html += '<p><span>' + key + '</span><span>' + value + '</span></p>';
            })


            if (index != -1) {
                days_html[index] += html;
            } else {
                html = '';
                days.push(value.dimensions.day);
                days_html.push(html);
            }
        })


        /*  for(var i=0;i<days.length;i++){
             $('#data_table').append('<div class="col-md-4 col-xs-12"><div class="card card-stats"><div class="card-header card-header-primary">'+days_html[i]+'</div></div></div>');
         } */
    }

    $('#admin_category_id').change(function(e){
        $.post(base_url+'read-category/'+$(this).val(),{'id':$(this).val()},function(e){
            if(e!=''){
                $('#admin_sub_parent').show();
                $("#admin_sub_category_parent_id").empty().html(e);
                // $("#category").attr('name','');    
                $("#admin_sub_category_id").empty().html('<option value="0">--seçim--</option>');
                $('#admin_sub_category').hide();
            }
            else{
                // $("#subcategory").attr('name','').empty();
                // $("#category").attr('name','category');
                
                $("#admin_sub_category_parent_id").empty().html('<option value="0">--seçim--</option>');
                $('#admin_sub_parent').hide();                 
               
                $("#admin_sub_category_id").empty().html('<option value="0">--seçim--</option>');
                $('#admin_sub_category').hide();
            }
        })
    })
    
    $('#admin_sub_category_parent_id').change(function(e){
        
        $.post(base_url+'read-category/'+$(this).val(),{'id':$(this).val()},function(e){
            
            if(e!='') {                
                $('#admin_sub_category').show();
                $("#admin_sub_category_id").empty().html(e);
            }
            else {                
                $("#admin_sub_category_id").empty().html('<option value="0">--seçim--</option>');
                $('#admin_sub_category').hide();
            }
        })
    })

    // function settigs_category(e){
    //     alert(e.category_id);
    //     alert(e.title);
    //     $('#admin_sub_parent').hide();
    //     $('#admin_sub_category').hide();
    //     $("#admin_sub_category_parent_id").empty();
    //     $("#admin_sub_category_id").empty();

    //     $.post(base_url+'read-category2',e.parent_id, function (res) {
    //         if(res.parent_id == '0'){
    //             res.tile
    //         }
    //         else {
    //             $.post(base_url+'read-category2',res.parent_id, function (res1) {


    //             });
    //         }

    //     });

    //     // $.each(e, function(item, value){
    //     //     if(item == "category_id"){
    //     //         alert(item + "; "+ value);
    //     //     }
    //     //     else if(item == 'parent_id'){
    //     //         $.post(base_url+'read-category1', '', function (e) {
                    
                    
    //     //         });

    //     //         alert(item + "; "+ value);
    //     //     }
    //     // });
    //     alert('iiiii')

    // }


})