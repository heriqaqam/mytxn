$(function(){

 

    var base_url = $('#base_url').val() + 'admin/';
    $('#brand_id').change(function(){
        read_models($(this).val());
    })


    function read_models(brand_id,model_id=0){
        $.post(base_url+'auctions/read_model',{'brand_id':brand_id,'model_id':model_id},function(e){
            $('#model_id').html(e);
        })
    }


    $.fn.auctions=function(e){
        read_models(e.brand_id,e.model_id);
        $('.form-image').empty();
        $.each(e.images,function(item,value){
            $('.form-image').write_image(value.src,value.num,value.id);
        })
        
    }
   

})