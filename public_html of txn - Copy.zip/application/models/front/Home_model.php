<?php
class home_model extends CI_Model
{

    public $string=false;
    function __construct() {
        parent::__construct();
        /* if(!$this->admin_model->get_admin(false)){
           $this->output->cache(120);   
        } */
        $this->load->model('front/users_model');
        $this->load->model('front/front_database_model');
        $this->load->model('front/auctions_model');
        $this->load->model('front/utils_model');
        global $string;
        $string=$this->string();
    }


    public function get_home_product($offset=1){
        $sort=$this->input->get('sortby');

        $sort_sql=array('id','desc');
        if(!empty($sort)){
            if($sort=='min'){
                $sort_sql=array('price','asc');
            }
            else if($sort=='max'){
                $sort_sql=array('price','desc');
            }
            else{
                $sort_sql=array('id','desc');
            }
        }
        $limit = $this->utils_model->get_limit();

        $product=$this->front_database_model->front_read('products',array('home'=>'true','share'=>'true','stok!='=>0),$sort_sql, $limit, ($offset-1)*$limit);
        
        if(count($product)>0){
            return $product;
        }
        else{
            return false;
        }
    }

    public function get_products($category_id){
        $sort=$this->input->get('sortby');
       
        $sort_sql=array('id','desc');
        if(!empty($sort)){
            if($sort=='min'){
                $sort_sql=array('price','asc');
            }
            else if($sort=='max'){
                $sort_sql=array('price','desc');
            }
            else{
                $sort_sql=array('id','desc');
            }
        }


        $product=$this->front_database_model->front_read('products',array('share'=>'true','category'=>$category_id),$sort_sql);
        if(count($product)>0){
            return $product;
        }
        else{
            return false;
        }
    }
    
    public function allbest(){
        $this->front_database_model->allbestok();
    }

    public function get_product($product_id){
        $product=$this->front_database_model->front_read_row('products',array('product_id'=>$product_id));
        if(count($product)>0){
            return $product;
        }
        else{
            return false;
        }
    }

    public function get_product_images($prodcut_id){
        return $this->front_database_model->front_read('products_image',array('product_id'=>$prodcut_id),array('num','asc'));
    }

    public function set_product_item($product){
        $store=$this->get_store($product['store_id']);
        if($store){
            return $this->show_data('product/product_item',array('product'=>$product));
        }
        else{
            return '';
        }
    }

    public function get_store($store_id){
        $result=$this->front_database_model->front_read_row('stores',array('share'=>'true','id'=>$store_id));
        if(count($result)>0){
            return $result;
        }
        else{
            return false;
        }
    }
  

    public function get_categories($parent_id=0,$direction=null){
        $where=array('parent_id'=>$parent_id,'share'=>true,'l_id'=>get_lang());
        if($direction!=null){
            $where['direction']=$direction;
        }
        $pages=$this->front_database_model->front_read('categories',$where,array('num','asc'));
        if(count($pages)>0){
            return $pages;
        }
        else{
            return false;
        }
    }


    public function get_category($category_id){
        $result=$this->front_database_model->front_read_row('categories',array('category_id'=>$category_id));
        if(count($result)>0){
            return $result;
        }
        else{
            return false;
        }
    }


    public function sitemap(){
        $url_ar     =array();
        $title_ar   =array();
        $pages=$this->front_database_model->front_read('pages',array('share'=>true,'seo_index'=>true));
        foreach($pages as $p){

            $url=base_url().$p['url_tag'];
            if(!empty($p['parent_id'])){
                $parent=$this->front_database_model->front_read_row('pages',array('page_id'=>$p['parent_id'],'l_id'=>$p['l_id']));
                $url=base_url().$parent['url_tag'].'/'.$p['url_tag'];
            }

            array_push($url_ar,$url);
            array_push($title_ar,$p['title']);
        }


        $language=$this->front_database_model->front_read('language',array('share'=>true));
        foreach($language as $l){
            $url=base_url().$b['url_tag'];
            array_push($url_ar,$url);
            array_push($title_ar,$l['title']);
        }
        return array('url'=>$url_ar,'title'=>$title_ar);
    }

    public function check_redirect(){
        $url=rtrim(base_url(),'/').$_SERVER['PATH_INFO'];
        $redirect=$this->front_database_model->front_read_row('redirects',array('old_url'=>$url));
        if(count($redirect)>0){
            header("Location:".$redirect['new_url'],TRUE,301);
            return false;
        }
        else{

            if($url[strlen($url)-1]!='/'){
                header("Location:".$url.'/',TRUE,301);
            }

            return true;
        }
    }

    public function string(){
        $string=array();
        $lang_setting=$this->front_database_model->front_read('lang_settings',array('l_id'=>get_lang()));
        foreach($lang_setting as $l)
        {
            $string=array_merge($string,array($l['selector']=>$l['value']));
        }
        return $string;
    }


    private function sliders(){
        return $this->front_database_model->front_query("select *from sliders where share='true' and (l_id=".get_lang()." or l_id=0) order by num asc");
        
    }


    private function language(){
        return $this->front_database_model->front_read('language',array('share'=>'true'),array('num','asc'));
    }


    private function contact(){
        $ar=array();
        $results=$this->front_database_model->front_read('settings');
        foreach($results as $r){
            $ar[$r['selector']]=$r['value'];
        }
        return $ar;
    }


    public function get_header_menu($parent_id=0){
        $pages=$this->front_database_model->front_read('pages',array('parent_id'=>$parent_id,'share'=>true,'header'=>true,'l_id'=>get_lang()),array('num','asc'));
        return $pages;
    }
    

    private function footer_menu($id=0){
        if($id==0){
            $pages=$this->front_database_model->front_read('pages',array('share'=>true,'footer'=>true,'l_id'=>get_lang()),array('num','asc'));
        }
        else{
            $pages=$this->front_database_model->front_read_row('pages',array('page_id'=>$id,'l_id'=>get_lang()));
        }
        return $pages;
    }


    public function get_footer_menu(){
        $footer_menu=$this->footer_menu();
		$ar      	=array();
		foreach($footer_menu as $m){

            $url='';
            if(!empty($m['parent_id'])){
                $url=$this->footer_menu($m['parent_id'])['url_tag'].'/';
            }

            array_push($ar,array($m['title'],$url.$m['url_tag']));
        }
        
        return $ar;
    }
    


    public function page($id){
        $page=$this->front_database_model->front_read_row('pages',array('page_id'=>$id,'share'=>true));
        if(count($page)>0){
            /* $other_page=$this->other_page($page['parent_id']);
            $ar=array('page'=>$page,'other_page'=>$other_page,'include'=>'');
            if(!empty($page['include']))
            {
                $ar['include']=$this->front_database_model->front_read_row('include',array('id'=>$page['include']))['url_tag'];
            } */
        return $page;
        }
        else
        {
            redirect(base_url().'404', 'location');
        }
    }

    
    private function other_page($id){
        if($id==0){
            return array();
        }
        else{
            return $this->front_database_model->front_read('pages',array('parent_id'=>$id,'share'=>true,'l_id'=>get_lang()),array('num','asc'));
        }
    }




    public function pagination($table='blogs',$data_show=9){
        $result=$this->front_database_model->front_query_row("select count(*) as say from ".$table." where share='true' and l_id=".get_lang());
        return $this->show_data('theme/pagination',array('data_count'=>$result['say'],'data_show'=>$data_show));
    }


    private function blog($id){
        $blog=$this->front_database_model->front_read_row('blogs',array('url_tag'=>$id,'share'=>true));
        if(count($blog)>0){
            return $blog;
        }
        else{
            redirect(base_url().'404', 'location');
        }
    }

    private function partners_list(){
        return $this->front_database_model->front_query("select *from partners where share=true and (l_id=".get_lang()." or l_id=0) order by num asc");
        
    }


    private function change_language($lang){
        $this->load->helper('cookie');
        set_cookie('lang',$lang['id'],time()+3600);
        set_cookie('url_tag',$lang['url_tag'],time()+3600);
        redirect(base_url(), 'location');
    }


    public function check_url($theme=false) {

        //change table name
        $table      =array('pages','language','categories','products');
        $segment    =$this->uri->segment_array();
        $url        =$segment[count($segment)];
        $template='';
        
        foreach($table as $t){

            $result=$this->front_database_model->front_read_row($t,array('url_tag'=>$url));
            
            if(count($result)>0){
                
                switch($t){
                    case 'pages':
                    $template='page';
                    break;
                    case 'categories':
                        $template='category';
                        break;
                    case 'products':
                        $template='product';
                        break;
                    case 'language':
                        $this->change_language($result);
                    break;
                }

                if($theme==true ){
                    echo $result['content'];
                }
                else{
                    $this->show($template, $result);
                }
               
            }
           
        }


        if(empty($template)){
            $this->show('theme/404');
        }

    }


    private function breadcumb(){

        //change table name
        $table=array('pages');


        $segment=$this->uri->segment_array();
        if(count($segment)>0){
            
            $ar=array();
            foreach($table as $t){
                $result=$this->front_database_model->front_read_in($t,'url_tag',$segment);
                $ar=array_merge($ar,$result);
            }

            $r          =array();
            
            if(count($segment)!=count($ar)){
               
            }
            else{
                foreach($ar as $a){
                    $index=array_search($a['url_tag'],$segment)-1;
                    $r[$index]=$a;
                }
            }
            return $this->show_data('theme/breadcumb',array('breadcumb'=>$r));
        }
        else{
            return array();
        }
    }


    public function reviews(){
        $sql="select 
        users.firstname as firstname,
        users.image as image,
        users.lastname as lastname,
        reviews.text as text,
        reviews.point as point
        
        from reviews
        left join users 
        on reviews.user_id=users.id
        where reviews.share=true order by reviews.id desc";
        return $this->front_database_model->front_query($sql);
    }


    public function show($template='home',$result='',$header=true,$footer=true,$js='',$css=''){
        global $string;
        $tmp_search = '';
        if(isset($result['title'])) 
            $temp_search = $result['title'];
        
        $ar=array(
            'seo_index'         =>1,
            'language'          =>$this->language(),
            'contact'           =>$this->contact(),
            'string'            =>$string,
            'breadcumb'         =>$this->breadcumb(),
            'og_image'          =>base_url().'assets/img/Logo.svg',
            'css'               =>$css,
            'js'                =>$js,
            'edit_controller'   =>'',
            'edit_id'           =>0,
            'sliders'           =>'',
            'description'       =>'',
            'title'             =>'',
            'keywords'          =>'',
            'content'           =>$result,
            'search'            =>$tmp_search,
        );
        


        switch($template)
        {
            case 'page':
                $ar['title']                =$ar['content']['page_title'];
                $ar['description']          =$ar['content']['description'];
                $ar['keywords']             =$ar['content']['keywords'];
                $ar['seo_index']            =$ar['content']['seo_index'];
                //
                $ar['edit_controller']      ='pages';
                $ar['edit_id']              =$ar['content']['id'];
                //
                
                $include=$this->front_database_model->front_read_row('include',array('id'=>$result['include']));

                $ar['content']['other_page']=$this->other_page($result['page_id']);

                if(!empty($ar['content']['include'])){

                    $ar['content']['include']=$include['url_tag'];
                }
                
            break;
            
            

            case 'category':
                $ar['title']                    =$ar['content']['title'].' - TexnoStar.az';
                $ar['description']              =$ar['content']['description'];
                $ar['keywords']                 =$ar['content']['keywords'];
                //
                $ar['edit_controller']          ='categories';
                $ar['edit_id']                  =$ar['content']['id'];
                //
            break;

            case 'product':
                $ar['title']                    =$ar['content']['title'].' - TexnoStar.az';
                $ar['description']              =$ar['content']['description'];
                $ar['content']['store']         =$this->get_store($ar['content']['store_id']);
                //
                $ar['edit_controller']          ='products';
                $ar['edit_id']                  =$ar['content']['id'];
                if($ar['content']['store']==false){
                    $this->show('theme/404');
                }
                //
            break;

            case 'theme/map':
                $ar['title']                    ='TexnoStar.az saytın xəritəsi';
                $ar['description']              ='Bloq məqalələr, ən son yeniliklər və xidmətlərimizə qısa keçidlər';
            break;
           

            case 'search':
                $ar['search']                   = $result['title'];
            break;
            case '404':
                $ar['seo_index']                =0;
		        $ar['title']                    ='TexnoStar.az';
		        $ar['description']              ='Wifi Kamera, VideoQeydiyyatçı, Domofon və 4G Kameralar';            
	        break;
	       
            default:
                $ar['title']                    =$ar['string']['home_title'];
                $ar['description']              =$ar['string']['home_description'];
                $ar['keywords']                 =$ar['string']['home_keywords'];
                $ar['sliders']                  =$this->sliders();
               // $ar['compress']=true;
            break;
        }


        $this->load->view('front/theme/header',$ar);
        //admin control
        if($this->admin_model->get_admin(false) and false){
            $admin_menu=$this->admin_model->get_admin_menu();
           $this->load->view('admin/easy_edit',array('admin_menu'=>$admin_menu));
        }
        //end admin  control

        
        //header page
        if($header==true){
            $this->load->view('front/theme/top',$ar);
        }
        else{
            $this->load->view('front/theme/topButton',$ar);
        }

        //template page
        $this->load->view('front/'.$template,$ar);

        //footer page
        if($footer==true){
            $this->load->view('front/theme/bottom',$ar);
        }

        
        $this->load->view('front/theme/footer',$ar);


    }

    
    public function show_data($template,$value=array()){
        global $string;
        $ar=array(
            'string'    =>$string
        );
        return $this->load->view('front/'.$template,array_merge($ar,$value),true);
    }


    public function set_form_token($token_name='contact_token'){
        $this->load->library('session');
        $token=get_token();
        $this->session->set_userdata($token_name,$token);
        return $token;
    }


    public function get_form_token($token_name,$token_value){
        $this->load->library('session');
        if($this->session->has_userdata($token_name)){
            if($this->session->userdata($token_name)==$token_value){
                return true;
            }
            else{
                return false;
            }
        }   
        else{
            return false;
        }
    }

    public function get_page_product($page){

        $home_product=$this->get_home_product($page);
        $html = "";

        if($home_product) {
        
            foreach($home_product as $product){
                $html .= $this->set_product_item($product);
            }
        }

        return $html;
    }
    public function get_products_pages($category_id, $limit = 20, $page=1){
        $sort=$this->input->get('sortby');
       
        $sort_sql=array('id','desc');
        if(!empty($sort)){
            if($sort=='min'){
                $sort_sql=array('price','asc');
            }
            else if($sort=='max'){
                $sort_sql=array('price','desc');
            }
            else{
                $sort_sql=array('id','desc');
            }
        }


        $product=$this->front_database_model->front_read('products',array('share'=>'true', 'stok >'=>0, 'category'=>$category_id),$sort_sql, $limit, $limit * ($page-1));
        // $product=$this->front_database_model->front_read('products',array('share'=>'true','category'=>$category_id),$sort_sql);
        if(count($product)>0){
            return $product;
        }
        else{
            return false;
        }
    }
    
    public function get_page_category_product($categor_id, $page=1){
        $product_items = "";
        $categories = $this->home_model->get_categories($categor_id);
        if($categories){
            foreach($categories as $list){
                $subcategories = $this->home_model->get_categories($list['category_id']);
                if($subcategories){
                    foreach($subcategories as $clist){
                        $childsubcategories = $this->home_model->get_categories($clist['category_id']);
                        if($childsubcategories){
                            foreach($childsubcategories as $csublist){
                                $csublist_categories = $this->home_model->get_categories($csublist['category_id']);
                                if($childsubcategories){
                                    foreach($csublist_categories as $cclist) {
                                        $limit = 5;
                                        $products=$this->home_model->get_products_pages($cclist['category_id'], $limit, $page);
                                        if($products){
                                            foreach($products as $product){
                                                $product_items .= $this->home_model->set_product_item($product);
                                            }
                                        }
                                    }                                
                                }
                                else {
                                    $limit = 5;
                                    $products=$this->home_model->get_products_pages($csublist['category_id'], $limit, $page);
                                    if($products){
                                        foreach($products as $product){
                                            $product_items .= $this->home_model->set_product_item($product);
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            $limit = 40;
                            $products=$this->home_model->get_products_pages($clist['category_id'], $limit, $page);
                            if($products){
                                foreach($products as $product){
                                    $product_items .= $this->home_model->set_product_item($product);
                                }
                            }
                        }
                    }        
                }
                else {
                    $limit = 40;
                    $products=$this->home_model->get_products_pages($list['category_id'], $limit, $page);
                    if($products){
                        foreach($products as $product){
                            $product_items .= $this->home_model->set_product_item($product);
                        }
                    }
                }
            }     
        }
        else{
            $limit = 40;
            $products=$this->home_model->get_products_pages($categor_id, $limit, $page);
            if($products){
                foreach($products as $product){
                    $product_items .= $this->home_model->set_product_item($product);
                }
            }
        }

        // $home_product=$this->get_home_product($page);
        // $html = "";

        // if($home_product) {
        
        //     foreach($home_product as $product){
        //         $html .= $this->set_product_item($product);
        //     }
        // }

        return $product_items;
    }
}
?>