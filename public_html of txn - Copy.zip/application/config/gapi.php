<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Google Analytics API - Account E-Mail
|--------------------------------------------------------------------------
*/
$config['account_email'] 	= 'autoauksion@autoauksion.iam.gserviceaccount.com';

/*
|--------------------------------------------------------------------------
| Google Analytics API - P12 Key File
|--------------------------------------------------------------------------
*/
$config['p12_key'] 			= 'assets/admin_js/AutoAuksion-cd2f2e665341.p12';

/*
|--------------------------------------------------------------------------
| Google Analytics API - Profile ID
|--------------------------------------------------------------------------
*/
$config['ga_profile_id']	= '203212625';