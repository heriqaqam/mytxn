<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['cpanel_username'] 	        = 'qhlc1wppqebb';
$config['cpanel_password'] 			= 'Qarabagbizim8%';
$config['cpanel_domain']	        = 'correcttechno.com';
$config['cpanel_ip']	            = '160.153.129.206';
$config['cpanel_port']              = '2083';