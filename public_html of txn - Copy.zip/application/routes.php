<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//admin routes
$route['correct-admin']                         = 'admin/account/login_form';

//front routes
$route['default_controller']                    = 'home';
$route['get_page_product_ctrl']                 = "home/get_page_product_ctrl";
$route['404_override']                          = 'home/not_found';
$route['translate_uri_dashes']                  = FALSE;
$route['admin/read-category1/(.+)']             = 'home/read_category1/$1';
$route['admin/read-category2/(.+)']             = 'home/read_category2/$1/$2';
$route['admin/read-category/(.+)']             = 'home/read_category/$1';
$route['admin/(.+)']                            = 'admin/$1';
$route['sitemap.xml']                           = 'sitemap/index';
$route['map']                                   = 'home/map';

$route['read-blogs']                             = 'home/read_blogs';

$route['send-message']                          = 'home/send_message';
$route['send-offer']                            = 'home/send_offer';

$route['register']                              = 'register';
$route['register-store']                        = 'register_store/index';
$route['register-store/submit']                 = 'register_store/submit';
$route['register/submit']                       = 'register/submit';
$route['confirmation']                          = 'confirmation/index'; 
$route['retry-sms']                             = 'confirmation/retry_sms';

$route['login']                                 = 'login';
$route['login/submit']                          = 'login/submit';

$route['recovery']                              = 'recovery';
$route['recovery/submit']                       = 'recovery/submit';
$route['recovery/save-password']                = 'recovery/save_password';

$route['create-store']                          = 'store';
$route['create-store/submit']                   = 'store/submit';

$route['profile']                               = 'profile/index';
$route['profile/(.+)']                          = 'profile/$1';  

$route['store']                                 = 'store/products';
$route['scroll/products_page']                   = 'store/products_page';
$route['store/add/submit']                      = 'store/saveproduct';
$route['store/product/edit/submit/(.+)']        = 'store/edit_product_submit/$1';
$route['store/product/edit/(.+)']               = 'store/edit_product/$1';
$route['store/product/ads/success/(.+)']        = 'store/check_payment/success/$1';
$route['store/product/ads/cancel/(.+)']         = 'store/check_payment/cancel/$1';
$route['store/product/ads/(.+)/(.+)']           = 'store/ads_product/$1/$2';
$route['store/delete_image']                    = 'store/delete_image';
$route['store/product/edit_stok/(.+)']          = 'store/edit_product_stok/$1';

$route['store/product/delete/(.+)']             = 'store/delete_product/$1';
$route['store/(.+)']                            = 'store/$1';
$route['viewStore/(.+)']                        = 'home/viewStore/$1';

$route['add-favorites']                         = 'profile/add_favorites';
$route['add-basket']                            = 'profile/add_basket';

$route['logout']                                ='login/logout';
$route['load-modal-view']                       = 'home/load_modal_view';
//page routes
$route['add-offer']                             = 'auctions/add_offer';
$route['read-offers']                           = 'auctions/read_offers';
$route['read-last-offers']                      = 'auctions/read_last_offers';

$route['read-noft']                             = 'profile/read_notification';
$route['reading-all-noft']                      = 'profile/reading_all_noft';
$route['read-total-balance']                    = 'profile/read_total_balance';


$route['order/success/(.+)']                    = 'profile/basket_check_payment/success/$1';
$route['order/cancel/(.+)']                     = 'profile/basket_check_payment/cancel/$1';
$route['basket/order/submit']                   = 'profile/basket_order_submit';
$route['basket/order']                          = 'profile/basket_order';
$route['basket/clear']                          = 'profile/basket_clear';
$route['basket/read-length']                    = 'profile/read_length';
$route['basket']                                = 'profile/basket';


$route['favorites/clear']                       = 'profile/favorites_clear';
$route['favorites']                             = 'profile/favorites';

// sticker
$route['search']                                ='search';
$route['search/search_page']                    ='search/search_page';
$route['search/submit']                         ='search/submit';

$route['read-category/(.+)']                    = 'home/read_category/$1';
$route['read-category1/(.+)']                    = 'home/read_category1/$1';

$route['(.+)']                                  = 'home/check_command';




