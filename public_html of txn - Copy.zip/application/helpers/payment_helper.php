<?php

/*
Array
(
    [Response] => Array
        (
            [Operation] => CreateOrder
            [Status] => 00
            [Order] => Array
                (
                    [OrderID] => 28342703
                    [SessionID] => B906DF9DEDDFCC1DA87B43494B60458E
                    [URL] => https://e-commerce.kapitalbank.az/index.jsp
                )

        )

)
*/

function pay_request($request){
    $url = "https://e-commerce.kapitalbank.az:5443/exec";
      $keyFile = "application/helpers/keys/merchant_name.key";
      $certFile = "application/helpers/keys/testmerchant.crt";
      $ch = curl_init();
          $options = array(
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_SSL_VERIFYHOST => false,
          CURLOPT_SSL_VERIFYPEER => false,
          CURLOPT_USERAGENT => 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)',
          CURLOPT_URL => $url ,
          CURLOPT_SSLCERT => $certFile ,
          CURLOPT_SSLKEY => $keyFile ,
          CURLOPT_POSTFIELDS => $request,
          CURLOPT_POST => true
          );
          curl_setopt_array($ch , $options);
          $output = curl_exec($ch);
          $array_data = json_decode(json_encode(simplexml_load_string($output)), true);
      return $array_data;
}


function set_payment($amount,$token,$returnLink){
    $request='<TKKPG>
    <Request>
            <Operation>CreateOrder</Operation>
            <Language>AZ</Language>
            <Order>
                  <OrderType>Purchase</OrderType>
                  <Merchant>E1000010</Merchant>
                  <Amount>'.$amount.'</Amount>
                  <Currency>944</Currency>
                  <Description>xxxxxxxx</Description>
                  <ApproveURL>'.get_base_url($returnLink.'/success/'.$token).'</ApproveURL>
                  <CancelURL>'.get_base_url($returnLink.'/cancel/'.$token).'</CancelURL>
                  <DeclineURL>'.get_base_url($returnLink.'/cancel/'.$token).'</DeclineURL>
            </Order>
    </Request>
   </TKKPG>';
   $data=pay_request($request);

   if($data['Response']['Status']=='00'){
    return array(
        'OrderID'       =>$data['Response']['Order']['OrderID'],
        'SessionID'     =>$data['Response']['Order']['SessionID'],
        'redirectURL'   =>"https://e-commerce.kapitalbank.az/index.jsp?ORDERID=".$data['Response']['Order']['OrderID']."&SESSIONID=".$data['Response']['Order']['SessionID']
    );
   }
   else{
       return false;
   }

}


function refund_payment($OrderID,$SessionID,$amount){
    $request='<TKKPG>
    <Request>
      <Operation>Refund</Operation>
      <Language>EN</Language>
      <Order>
        <Merchant>your_merchant_id</Merchant>
        <OrderID>'.$OrderID.'</OrderID>
          <Positions>
            <Position>
              <PaymentSubjectType>1</PaymentSubjectType>
              <Quantity>1</Quantity>
              <Price>1</Price>
              <Tax>1</Tax>
              <Text>name position</Text>
              <PaymentType>2</PaymentType>
              <PaymentMethodType>1</PaymentMethodType>
            </Position>
          </Positions>
      </Order>
      <Description>refund test</Description>
      <SessionID>'.$SessionID.'</SessionID>
      <Refund>
        <Amount>'.$amount.'</Amount>
        <Currency>944</Currency>
        <WithFee>false</WithFee>
      </Refund>
      <Source>1</Source>
    </Request>
</TKKPG>';

}






?>