<?php

function image_base64($file){
    $contents=file_get_contents($file);
    return base64_encode($contents);
}

//mktime ( int $hour [, int|null $minute = null [, int|null $second = null [, int|null $month = null [, int|null $day = null [, int|null $year = null ]]]]] ) : int|false

function set_time($date,$time){
    $t=explode(':',$time);
    $d=explode('-',$date);
    return mktime($t[0],$t[1],0,$d[1],$d[2],$d[0]);
}


function get_time($time){
    return array(
        'date'  =>date('Y-m-d',$time),
        'hour'  =>date('H:i:s',$time)
    );
}

function get_auction_active($start,$end){
	$time=time();
	if($time>=$start and $time<=$end){
		return true;
	}
	else{
		return false;
	}
}

function get_auction_start($start){
	$time=time();
	if($time>=$start){
		return true;
	}
	else{
		return false;
	}
}

function get_auction_end($end){
	$time=time();
	
	if($time<=$end){
		return true;
	}
	else{
		return false;
	}
}

function get_price($price){
	$currency=get_currency();
	return ($currency[1]*$price).' '.$currency[0];
}


function get_currency_api(){
	$url='https://v6.exchangerate-api.com/v6/b5f40ce7af8079c6b368f479/latest/AZN';
	$data=file_get_contents($url);
	if($data){
		$data=json_decode($data,true);
		return $data['conversion_rates'];
	}
	else{
		return false;
	}
}


function get_currency(){
	if(isset($_COOKIE['currency']) and isset($_COOKIE['currency_value'])){
		return array($_COOKIE['currency'],$_COOKIE['currency_value']);
	}
	else{
	    return array('AZN',1);
	}
}

?>