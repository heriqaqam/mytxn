<?php

// Database credentials
$servername = "localhost";
$username = "u849707844_texnostar";
$password = "bK!vWM~1~";
$dbname = "u849707844_texnostar";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch product and category links
$product_sql = "SELECT url_tag, last_modified FROM products";
$category_sql = "SELECT url_tag, last_modified FROM categories";

$product_result = $conn->query($product_sql);
$category_result = $conn->query($category_sql);

// Create a new DOMDocument
$doc = new DOMDocument('1.0', 'UTF-8');
$doc->formatOutput = true;

// Create and append the root element
$urlset = $doc->createElement('urlset');
$urlset->setAttribute('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
$doc->appendChild($urlset);

// Process category links
while($row = $category_result->fetch_assoc()) {
    $url = $doc->createElement('url');
    $url->appendChild($doc->createElement('loc', 'https://texnostar.az/' . $row["url_tag"]));
    $formatted_date = date("Y-m-d\TH:i:s+04:00", strtotime($row["last_modified"]));
    $url->appendChild($doc->createElement('lastmod', $formatted_date));
    $url->appendChild($doc->createElement('changefreq', 'weekly'));
    $url->appendChild($doc->createElement('priority', '1.0'));
    $urlset->appendChild($url);
}

// Process product links
while($row = $product_result->fetch_assoc()) {
    $url = $doc->createElement('url');
    $url->appendChild($doc->createElement('loc', 'https://texnostar.az/' . $row["url_tag"]));
    $formatted_date = date("Y-m-d\TH:i:s+04:00", strtotime($row["last_modified"]));
    $url->appendChild($doc->createElement('lastmod', $formatted_date));
    $url->appendChild($doc->createElement('changefreq', 'weekly'));
    $url->appendChild($doc->createElement('priority', '0.5'));
    $urlset->appendChild($url);
}



// Save the XML to a file
$file_path = "/home/u849707844/domains/texnostar.az/public_html/sitemap.xml";
$doc->save($file_path);

// Close the database connection
$conn->close();

echo "Sitemap generated and saved successfully!";

?>
