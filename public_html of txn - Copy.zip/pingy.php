<?php
// Function to ping the sitemap to various search engines
function pingSitemap($sitemapUrl) {
    $searchEngines = array(
        'Google' => 'https://www.google.com/ping?sitemap=',
        'Bing' => 'https://www.bing.com/ping?sitemap=',
        'Yandex' => 'https://webmaster.yandex.com/site/ping?host=',
        // Add other search engines here as needed
    );

    foreach ($searchEngines as $engine => $pingUrl) {
        $urlToPing = $pingUrl . urlencode($sitemapUrl);
        $response = file_get_contents($urlToPing);
        // Optionally, you can check the response for success and handle any errors if needed
        // For example, check if the response contains "Sitemap notification successful" for Google
    }
}

// Replace 'https://www.shopstar.az/sitemap.xml' with the actual URL of your sitemap
$sitemapUrl = 'https://www.shopstar.az/sitemap.xml';

// Ping the sitemap to various search engines
pingSitemap($sitemapUrl);

// Success message
echo "Sitemap pinged successfully to search engines!";
?>
