<?php

// Configuration
$allowedIPs = ['31.220.106.54'];
$key = "b9c0bd0a49f948b8a371fe5c1e224f7f";
$sitemapURL = "https://www.tezalsat.az/sitemap.xml";

$endpoints = [
    "bing" => "https://www.bing.com/indexnow",
    "yandex" => "https://yandex.com/indexnow"
];

// IP check for security
// Bypass if the script is running via CLI (like in a cron job)
if (php_sapi_name() !== 'cli') {
    if (!isset($_SERVER['REMOTE_ADDR']) || !in_array($_SERVER['REMOTE_ADDR'], $allowedIPs)) {
        die('Access denied.');
    }
}

// Fetch and parse the sitemap
$sitemap = file_get_contents($sitemapURL);
$xml = simplexml_load_string($sitemap);
$urls = [];

foreach ($xml->url as $url) {
    $urls[] = (string)$url->loc;
}

// Submit the URLs
foreach ($endpoints as $name => $endpoint) {
    $ch = curl_init();

    if ($name == "bing") {
        $bingURL = $endpoint . "?url=" . implode("&url=", $urls) . "&key=" . $key;
        curl_setopt($ch, CURLOPT_URL, $bingURL);
    } else {
        $data = json_encode([
            "host" => "www.tezalsat.az",
            "key" => $key,
            "urlList" => $urls
        ]);
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    }

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    echo "Response from {$name} (HTTP Code: {$httpCode}): {$response}<br>";
}

echo "Script completed.";

?>
