<?php

// Database credentials
$servername = "localhost";
$username = "u849707844_texnostar";
$password = "bK!vWM~1~";
$dbname = "u849707844_texnostar";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT image FROM products_image";
$result = $conn->query($sql);

$keepFiles = [];

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $imageDetails = json_decode($row["image"], true);
        if (!empty($imageDetails["webp_url"])) {
            $keepFiles[] = $imageDetails["webp_url"];
        }
        if (!empty($imageDetails["link"])) {
            $keepFiles[] = $imageDetails["link"];
        }
    }
} else {
    echo "0 results";
}
$conn->close();

// Define the folders
$folders = [
    '/home/u849707844/domains/pixelshop.pro/public_html/uploads/thumb',
    '/home/u849707844/domains/pixelshop.pro/public_html/uploads/webp'
];

foreach ($folders as $folder) {
    // Scan the directory for all files
    $allFiles = scandir($folder);

    // Filter out ".", "..", and subdirectories
    $allImages = array_filter($allFiles, function ($file) use ($folder) {
        return is_file($folder . '/' . $file);
    });

    // Calculate which files to delete (all images except the ones to keep)
    $deleteFiles = array_diff($allImages, $keepFiles);

    // Loop through and delete the files
    foreach ($deleteFiles as $file) {
        $filePath = $folder . '/' . $file;
        if (unlink($filePath)) {
            echo "Deleted: $filePath\n";
        } else {
            echo "Could not delete: $filePath\n";
        }
    }
}

?>
